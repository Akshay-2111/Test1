#' @export
detect_sensor_type <- function(sensor_name){
  sensor_name %>%
    str_detect("_a_|_b_|_c_|_d_|_e_|_n_|_s_|_ne_|_nw_|_se_|_sw_|_e_|_w_|_nne_|_nnw_|_sse_|_ssw_|_ene_|_ese_|_wsw_|_wnw_")
}

#' @export
rename_number_with_point <- function(df){
  df %>%
    colnames() %>%
    enframe(name = NULL, value = "old_name") -> cn
  cn %>%
    mutate(new_name = old_name %>% str_replace_all("([0-9]+)_([0-9])", "\\1.\\2")) -> new_name
  df %>%
    data.table::setnames(new_name$old_name, new_name$new_name)
  return(df)
}

#' @export
rename_unique_ws <- function(df){
  df %>%
    colnames() -> raw_colnames
  raw_colnames %>%
    enframe(name = NULL, value = "x") %>%
    mutate(row_no = row_number()) -> oldnames
  oldnames %>%
    mutate(l1 = x %>% str_detect("ws")) %>%
    filter( l1== T) %>%
    mutate(l2 = x %>% str_detect("sd|min|max")) %>%
    filter( l2== F) %>%
    mutate(l3 = x %>% str_detect("vws")) %>%
    mutate(height = x %>% parse_number()) %>%
    mutate(height_mts = paste(height, 'meters')) %>%
    rename(sensor_name = x) %>%
    mutate(speed_type = substr(sensor_name,1,1)) %>%
    group_by(speed_type,height) %>%
    mutate(count = n()) %>% ungroup() %>% dplyr::select(-c(l1,l2,l3), row_no) -> var_ht_count
  var_ht_count %>%
    filter(count == 1) %>%
    mutate(x1 = sensor_name %>% detect_sensor_type()) %>%
    filter(x1 == T) %>%
    dplyr::select(-x1) %>%
    mutate(sensor_name = sensor_name %>%
             str_remove_all("_a_|_b_|_c_|_d_|_e_|_n_|_s_|_ne_|_nw_|_se_|_sw_|_e_|_w_|_nne_|_nnw_|_sse_|_ssw_|_ene_|_ese_|_wsw_|_wnw_") %>%
             str_replace_all("([0-9]+)", "\\1_")) %>%
    dplyr::select(sensor_name, row_no)-> renamed_cols
  oldnames %>%
    left_join(renamed_cols, by = "row_no") %>%
    mutate(sensor_name = ifelse(is.na(sensor_name) == T, x , sensor_name)) -> new_name
  df %>%
    data.table::setnames(new_name$x, new_name$sensor_name) -> df_renamed
  return(df_renamed)
}

#' @export
raw_txt_read_clean <- function(txt){
  x <- 1:15
  y<- 0
  for (val in x) {
    txt %>%
      read_tsv(col_names = T, skip = y) -> df
    y = y+1
    df %>% names() -> dfn
    dfn[1] -> dfdt
    #if(dfdt == "Date"){
    if (dfdt == "Date/Time"){
      break
    }
  }

  return(df %>%
           # slice(-1) %>%
           clean_names() %>%
           rename_unique_ws() %>%
           rename_number_with_point() %>%
           dplyr::select("date_time",starts_with("ws"), starts_with("wd"), starts_with("vws"),
                         starts_with("t"), starts_with("p"), starts_with("rh")) %>%
           transmute_all(if9999) %>%
           transmute_all(if9999_1) %>%
           mutate(date_time = date_time %>% date_time_formater()))
}

#' @export
get_predictions_from_models <- function(x,models){
  f1 <- function(x_vec,model,n){
    tibble(x = x_vec) %>%
      tidypredict_to_column(model) %>%
      rename_with(~ tolower(gsub("fit", paste0("predicted_from_model_",n), .x, fixed = TRUE)))
  }

  f2 <- function(n){
    x %>%
      f1(models[[n]],n)
  }

  f3 <- function(){
    1:length(models) %>%
      map_dfc(f2) %>%
      dplyr::select(-contains("..")) %>%
      mutate(x = x) %>%
      dplyr::select(x, everything())
  }

  f3()
}

#' @export
raw_with_mean <- function(df){
  df -> raw1
  df  %>% colnames() %>% enframe(name = NULL, value = "x") -> cn_mean

  cn_mean %>%
    mutate(l1 = x %>% str_detect("ws")) %>%
    filter( l1== T) %>%
    mutate(l2 = x %>% str_detect("sd|min|max")) %>%
    filter( l2== F) %>%
    mutate(l3 = x %>% str_detect("vws")) %>%
    mutate(height = x %>% parse_number()) %>%
    mutate(height_mts = paste(height, 'meters')) %>%
    rename(sensor_name = x) %>%
    mutate(speed_type = substr(sensor_name,1,1)) %>%
    group_by(speed_type,height) %>%
    mutate(count = n()) %>% ungroup() %>% dplyr::select(-c(l1,l2,l3)) -> var_ht_count


  if(max(var_ht_count$count) > 1){
    var_ht_count %>%
      filter(count > 1) %>%
      group_by(height) %>%
      summarise(ncol = sensor_name %>% glue_collapse(sep = ",")) %>%
      separate(ncol, into = c("asen", "bsen"), sep = ",") %>%
      drop_na() -> var_ht_separated

    #map_dfc mean calculation
    wind_mean <- function(x,y){
      mean(c(x,y), na.rm = T)
    }

    parallel_mean <- function(num, df1, df2) {
      df1 %>%
        slice(num) -> var_ht_sliced

      var_ht_sliced$asen %>%
        str_replace("_a_|_b_|_c_|_d_|_e_|_n_|_s_|_ne_|_nw_|_se_|_sw_|_e_|_w_|_nne_|_nnw_|_sse_|_ssw_|_ene_|_ese_|_wsw_|_wnw_", "_") -> new_mean_name

      df2 %>%
        mutate({{new_mean_name}} := pmap(list(UQ(sym(var_ht_sliced$asen)), UQ(sym(var_ht_sliced$bsen))), wind_mean)) %>%
        dplyr::select(!!new_mean_name) %>% unlist() %>% enframe(name = NULL, value = new_mean_name)  -> dat

    }

    raw1 %>% bind_cols(1:nrow(var_ht_separated) %>%
                         map_dfc(parallel_mean,var_ht_separated, raw1)) -> raw1

  }

  return(raw1)
}

#' @export
dropdownButton <- function(label = "",
                           status = c("default", "primary", "success",
                                      "info", "warning", "danger"), ..., width = NULL) {

  status <- match.arg(status)
  # dropdown button content
  html_ul <- list(
    class = "dropdown-menu",
    style = if (!is.null(width))
      paste0("width: ", validateCssUnit(width), ";"),
    lapply(X = list(...), FUN = tags$li, style = "margin-left: 10px; margin-right: 10px;")
  )
  # dropdown button appearence
  html_button <- list(
    class = paste0("btn btn-", status," dropdown-toggle"),
    type = "button",
    `data-toggle` = "dropdown"
  )
  html_button <- c(html_button, list(label))
  html_button <- c(html_button, list(tags$span(class = "caret")))
  # final result
  tags$div(
    class = "dropdown",
    do.call(tags$button, html_button),
    do.call(tags$ul, html_ul),
    tags$script(
      "$('.dropdown-menu').click(function(e) {
      e.stopPropagation();
});")
  )
}

#first letter caps
#' @export
firstup <- function(x) {
  substr(x, 1, 1) <- toupper(substr(x, 1, 1))
  x
}

#' @export
pu <- function(df,col){
  df %>%
    pull({{col}}) %>%
    # pull(col) %>%
    unique()
}

#' @export
if9999 <- function(x){ifelse(x == 9999, NA, x)}

#' @export
if9999_1 <- function(x){ifelse(x == -9999, NA, x)}

#' @export
date_time_formater <- function(x){
  if(is.numeric(x)){
    x %>% as_datetime(origin = lubridate::origin)
  } else {
    x %>% dmy_hm()
  }
}

#' @export
select_subset_colnames <- function(df,check_string){
    grep(check_string, df %>%
           colnames(), value = TRUE)
}

#' @export
subset_col_vec <- function(vec,check_string){
  grep(check_string, vec, value = TRUE)
}

#' @export
select_subset_cols <- function(df,param_vec){
  df %>%
    dplyr::select(date_time, param_vec)
}

#' @export
augument_with_ymd <- function(df){
  df %>%
    mutate(year = date_time %>% year()) %>%
    mutate(month = date_time %>%  month()) %>%
    mutate(day = date_time %>% day())
}

#' @export
augument_with_ymdplus <- function(df){
  df %>%
    mutate(year = date_time %>% year()) %>%
    mutate(month = date_time %>%  month()) %>%
    mutate(day = date_time %>% day()) %>%
    mutate(hour = date_time %>% hour()) %>%
    mutate(date_time_hr = date_time %>% substr(1,13)) %>%
    mutate(date_time_hr = date_time_hr %>% as.POSIXct(format = "%Y-%m-%d %H")) %>%
    mutate(date = date_time %>% date()) %>%
    mutate(week = date_time %>% week()) %>%
    mutate(month = format(date %>% as.Date(),"%Y-%m") ) %>%
    mutate(month = month %>% parse_date_time( "ym"))
}

#' @export
get_meta_data <- function(cols){
  cols %>%
    enframe(value = "colname") %>%
    mutate(ht = colname %>% parse_number()) %>%
    mutate(
      sensor_type = case_when(
        colnames_containing2(colname,"vws") ~ "vws",
        colnames_containing2(colname,"ws") ~ "ws",
        colnames_containing2(colname,"wd") ~ "wd",
        colnames_containing2(colname,"t_") ~ "t",
        colnames_containing2(colname,"rh_") ~ "rh",
        colnames_containing2(colname,"p_") ~ "p",
        TRUE ~ "NA"
      )
    ) %>%
    mutate(
      stats_type = case_when(
        colnames_containing2(colname,"mean") ~ "mean",
        colnames_containing2(colname,"sd") ~ "sd",
        colnames_containing2(colname,"min") ~ "min",
        colnames_containing2(colname,"max") ~ "max",
        colnames_containing2(colname,"turb") ~ "turb",
        TRUE ~ "other"
      )
    )
}

#' @export
get_uni_sensor_table <- function(meta_df){
  meta_df %>%
    filter(stats_type == "mean") %>%
    group_by(ht,sensor_type) %>%
    summarise(count = n()) %>%
    ungroup() %>%
    filter(count == 1) %>%
    mutate(mean_colname = paste0(sensor_type,"_",ht,"_","mean_m_s"))
}

#' @export
get_multi_sensor_table <- function(meta_df){
  meta_df %>%
    filter(stats_type == "mean") %>%
    group_by(ht,sensor_type) %>%
    summarise(count = n()) %>%
    ungroup() %>%
    filter(count > 1) %>%
    mutate(mean_colname = paste0(sensor_type,"_",ht,"_","mean_m_s"))
}

#' @export
get_sensor_table <- function(meta_df){
  meta_df %>%
    filter(stats_type == "mean") %>%
    group_by(ht,sensor_type) %>%
    summarise(count = n()) %>%
    ungroup() %>%
    mutate(mean_colname = paste0(sensor_type,"_",ht,"_","mean_m_s"))
}

# Used for wind shear analysis
#' @export
get_extrapolated_wind_speed <- function(h,m){
  # h is extrapolated vertical height
  # m is the model
  m %>%
    predict(h %>% enframe(value = "ht")) %>%
    exp() %>%
    as.numeric() %>%
    round(2)
}

#' @export
get_multi_sensor_sd_table <- function(meta_df){
  meta_df %>%
    filter(stats_type == "sd") %>%
    group_by(ht,sensor_type) %>%
    summarise(count = n()) %>%
    ungroup() %>%
    filter(count > 1) %>%
    mutate(sd_colname = paste0(sensor_type,"_",ht,"_","sd_m_s"))
}

#' @export
get_multi_sensor_turb_table <- function(meta_df){
  meta_df %>%
    # shfsjh %>%
    filter(sensor_type == "ws") %>%
    filter(stats_type %in% c("mean","sd")) %>%
    filter(colname %>% str_detect("(.*)\\d(_)(mean|sd)(.*)")) %>%
    group_by(ht) %>%
    summarise(newcol = colname %>% glue_collapse(sep = ",")) %>% #View()
    separate(newcol, into = c("ws_mean","ws_sd"), sep = ",") %>% #View()
    drop_na() %>%
    mutate(turb_colname = ws_mean %>% str_replace("mean","turb")) #%>% View()
}

#' @export
get_multi_sensor_mean_and_sd_table <- function(meta_df){
  meta_df %>%
    filter(stats_type %in% c("mean","sd")) %>%
    group_by(ht,sensor_type) %>%
    summarise(count = n()) %>%
    ungroup() %>%
    filter(count > 1) %>%
    mutate(sd_colname = paste0(sensor_type,"_",ht,"_","sd_m_s"))
}

#' @export
compute_mean_column_per_timestamp <- function(n,df_raw,mst){
  df_raw %>%
    dplyr::select(starts_with(mst %>% slice(n) %>% pull(sensor_type))) %>%
    dplyr::select(contains(mst %>% slice(n) %>% pull(ht) %>% as.character())) %>%
    dplyr::select(contains("mean")) %>%
    mutate(s_no = row_number()) %>%
    pivot_longer(-s_no,names_to = "names", values_to = "vals") %>%
    group_by(s_no) %>%
    summarise(mean_val = vals %>% mean(na.rm = TRUE)) %>%
    pull(mean_val)
}

#' @export
compute_sd_column_per_timestamp <- function(n,df_raw,mst){
  df_raw %>%
    dplyr::select(starts_with(mst %>% slice(n) %>% pull(sensor_type))) %>%
    dplyr::select(contains(mst %>% slice(n) %>% pull(ht) %>% as.character())) %>%
    dplyr::select(contains("sd")) %>%
    mutate(s_no = row_number()) %>%
   # dplyr::select(-{{dt}}) %>%
    pivot_longer(-s_no,names_to = "names", values_to = "vals") %>%
    group_by(s_no) %>%
    summarise(sd_val = vals %>% mean(na.rm = TRUE)) %>%
    pull(sd_val)
}

#' @export
compute_turb_column_per_timestamp <- function(n,df,mst){
  mst[n,-1] %>%
    as.character() -> mst_vector

  df[,mst_vector[1:2]] -> df1
  df1[,3] <- ((df1[,2]/df1[,1]) * 100) %>% round(1)

  colnames(df1) <- mst_vector

  df1 %>%
    return()
}



# compute_windrose_bin_num <- function(val,n){
#   n %>%
#     wrb1() -> wrb
#   which(val %>% between(wrb$lb,wrb$ub)) %>%
#     return()
# }

#' @export
sp_fun <- function(sen1,sen2, df){

  df %>%
    dplyr::select(date_time,sen1,sen2) -> tt

  if(sen1 == sen2){

    setnames(tt, c('date_time','sen1'))
    tt %>%
      mutate(sensor_ratio = sen1/sen1) %>%
      mutate(date = date(date_time)) %>%
      mutate(month = month(date_time)) %>%
      mutate(month = format(date,"%B") %>% factor() %>% fct_inorder() ) %>%
      mutate(month = format(date %>% as.Date(), "%Y-%m")) %>%
      mutate(month = month %>% parse_date_time("ym")) %>%
      mutate(year_month = format(date,"%Y %b") %>% factor() %>% fct_inorder()) %>%
      group_by(month) %>%
      summarise(sensor_ratio = mean(sensor_ratio,na.rm = T))-> d2

  }else{
    setnames(tt, c('date_time','sen1','sen2'))
    tt %>%
      mutate(sensor_ratio = sen1/sen2) %>%
      mutate(date = date(date_time)) %>%
      mutate(month = month(date_time)) %>%
      mutate(month = format(date,"%B") %>% factor() %>% fct_inorder() ) %>%
      mutate(month = format(date %>% as.Date(), "%Y-%m")) %>%
      mutate(month = month %>% parse_date_time("ym")) %>%
      mutate(year_month = format(date,"%Y %b") %>% factor() %>% fct_inorder()) %>%
      group_by(month) %>%
      summarise(sensor_ratio = mean(sensor_ratio,na.rm = T))-> d2

  }

}

#' @export
colnames_containing <- function(char_vector,string){
  rx_find(value = string) %>%
    grep(char_vector,
         value = TRUE)
}

#' @export
colnames_containing2 <- function(char_vector,string){
  rx_find(value = string) %>%
    grepl(char_vector)
}


#scatter plot 2 function ----
#' @export
scatter_plot2_func <- function(x_axis_ws,y_axis_ws,color_by_wd,winddata_mean,mast_name){

  if(x_axis_ws == y_axis_ws){
    ggplot() +
      labs(title = "Both the selected sensors are same")
  } else {
    winddata_mean -> wdat_mean
    wdat_mean %>%
      dplyr::select(c(x_axis_ws,y_axis_ws,color_by_wd)) %>%
      drop_na()  -> int_data_2

    setnames(int_data_2, c('x','y','z'))

    x_axis_ws %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> xlab
    y_axis_ws %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> ylab
    color_by_wd  %>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD") -> zlab


    int_data_2 %>%
      ggplot(aes(x = x,
                 y = y,
                 colour = z)) +
      geom_point(size = 1) +
      scale_colour_gradient(low = "lightblue", high = "darkblue") +
      labs(x = xlab,
           y = ylab,
           color = zlab,
           title = paste0("Mast Name: ", mast_name,"\n","WS-Sensors vs WS-Sensors at Different Heights(color-WD)")) +
          # title = paste0("Mast Name: ", mast_name)) +
      scale_x_continuous(limits=c(0,24),breaks=seq(0,24,1))+
      scale_y_continuous(limits=c(0,24),breaks=seq(0,24,1))+
      geom_vline(xintercept = seq(0,24,0.2), alpha = 0.05) +
      geom_vline(xintercept = seq(0,24,1), alpha = 0.1) +
      geom_hline(yintercept = seq(0,24,0.2), alpha = 0.05) +
      geom_hline(yintercept = seq(0,24,1), alpha = 0.1) +
      #  ggtitle("Primary WS Sensor vs WS Sensors at Different Heights(color-WD)") +
      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05))  -> p

  }
}

#' @export
lm_equation_sp_func <- function(xlm, ylm ,winddata_mean){

  if(xlm == ylm){
    list(m = NA)
  } else {
    winddata_mean -> wdat_mean
    wdat_mean %>%
      dplyr::select(xlm, ylm) %>%
      drop_na() -> df_s_1_2

    setnames(df_s_1_2, c("x", "y"))

    m <- lm(y ~ x, df_s_1_2); #im not sure about the formula, please check
    m$coefficients[2] %>%  round(4) %>% as.character() -> m1
    (cor(df_s_1_2$x,df_s_1_2$y,use = "na.or.complete")^2) %>% round(4) -> rr
    list(m = m1,r2 = rr) -> lmeq #return list with m and r2 value
    return(lmeq)
  }
}


#scatter plot 3 ----
#' @export
scatter_plot3_func <- function(x_axis_ws,y_axis_ws,winddata_mean,mast_name1){

  if(x_axis_ws == y_axis_ws){
    ggplot() +
      labs(title = "Both the selected sensors are same")
  } else {
   winddata_mean -> wdat_mean
    wdat_mean %>%
      dplyr::select(c(x_axis_ws,y_axis_ws,date_time)) %>%
      drop_na()  -> int_data_3

    setnames(int_data_3, c('x','y','z'))

    x_axis_ws %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> xlab
    y_axis_ws %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> ylab
    # highest_wd  %>% str_replace_all("_u_00b0", " [deg]") -> zlab

    int_data_3 %>%
      mutate(z = as.POSIXct(z,origin = '1900-01-01')) %>%
      mutate(hour = hour(z) ) %>%
      ggplot(aes(x = x,
                 y = y,
                 colour = hour)) +
      geom_point(size = 1) +
      scale_colour_gradient(low = "lightblue", high = "darkblue") +
      labs(x = xlab,
           y = ylab,
           color = 'Hour',
           #title = paste0("Mast Name: ", mast_name1)) +
      title = paste0("Mast Name: ", mast_name1,"\n","WS Sensor vs WS Sensors at Different Heights(color-Hour)")) +
      scale_x_continuous(limits=c(0,24),breaks=seq(0,24,1))+
      scale_y_continuous(limits=c(0,24),breaks=seq(0,24,1))+
      geom_vline(xintercept = seq(0,24,0.2), alpha = 0.05) +
      geom_vline(xintercept = seq(0,24,1), alpha = 0.1) +
      geom_hline(yintercept = seq(0,24,0.2), alpha = 0.05) +
      geom_hline(yintercept = seq(0,24,1), alpha = 0.1) +
      # ggtitle("Primary WS Sensor vs WS Sensors
      #       at Different Heights(color-Hour)") +
      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05))  -> p

    #  p %>% ggplotly() %>% toWebGL()
  }
}


#scatter plot 4 ----
#' @export
scatter_plot4_func <- function(x,y,z,fil,winddata_mean,mast_name1){
  #winddata() -> wdat
  winddata_mean -> wdat_mean
  wdat_mean %>%
    rename("var1" = x) -> wdat1
  # wdat1%>%
  #   rename("var2" = y)->> wdat2

  x %>% str_replace_all("_u_00b0", " [\u00b0]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD") -> xlab
  y %>% str_replace_all("_u_00b0", " [\u00b0]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD") -> ylab
  z %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> zlab

  cv_num <- function(x){
    round(x/.05)*.05
  }

  "colorpalwind.rds" %>%
    readRDS() -> colorpalwind

  tibble(x = 1:27,
         y = colorpalwind %>% unique()) -> lp

  lp %>%
    mutate(y1 = y %>% lead()) -> lp1

  colpalpicker <- function(x,y){
    colfunc<-colorRampPalette(c(x,y))
    colfunc(6)[1:5]
  }

  lp1 %>%
    mutate(no = c(seq(3, 9, 0.25), 9.5, 10)) %>%
    slice(-c(26, 27)) %>%
    mutate(pal = pmap(list(y,y1), colpalpicker)) -> color_pal_ws


  lp %>%
    mutate(y1 = y %>% lead()) %>% #View()
    mutate(pal = pmap(list(y,y1), colpalpicker)) -> colorpal1

  color_pal_ws %>%
    pull(pal) -> colorpallist


  c(colorpallist[1] %>% unlist(), colorpallist[2]%>% unlist(),
    colorpallist[3] %>% unlist(), colorpallist[4]%>% unlist(),
    colorpallist[5] %>% unlist(), colorpallist[6]%>% unlist(),
    colorpallist[7] %>% unlist(), colorpallist[8]%>% unlist(),
    colorpallist[9] %>% unlist(), colorpallist[10]%>% unlist(),
    colorpallist[11] %>% unlist(), colorpallist[12]%>% unlist(),
    colorpallist[13] %>% unlist(), colorpallist[14]%>% unlist(),
    colorpallist[15] %>% unlist(), colorpallist[16]%>% unlist(),
    colorpallist[17] %>% unlist(), colorpallist[18]%>% unlist(),
    colorpallist[19] %>% unlist(), colorpallist[20]%>% unlist(),
    colorpallist[21] %>% unlist(), colorpallist[22]%>% unlist(),
    colorpallist[23] %>% unlist(), colorpallist[24]%>% unlist(),
    colorpallist[25] %>% unlist()) %>% unique() -> colorlist

  tibble(colorhex = colorlist) -> color_hex_grad

  color_hex_grad %>%
    left_join(color_pal_ws %>%
                dplyr::select(c(2, 4)) %>%
                rename("colorhex" = "y"), by = "colorhex") -> c1

  tibble(no2 = c(seq(3, 9, 0.05), 0,0,0,0)) -> c2

  c1 %>%
    bind_cols(c2) %>%
    slice(1:121) -> c3

  colpalpicker1 <- function(x,y){
    colfunc<-colorRampPalette(c(x,y))
    colfunc(11)[1:10]
  }


  tibble(y = c("#FF7CBA", "#D0D0D0", "#FFFFFF")) %>%
    mutate(y1 = y %>% lead()) %>%
    mutate(pal = pmap(list(y,y1), colpalpicker1)) -> ws_col_9_10

  ws_col_9_10 %>%
    pull(pal) -> colorpallist1


  c(colorpallist1[1] %>% unlist(), colorpallist1[2]%>% unlist(),
    colorpallist1[3] %>% unlist()) %>% unique() -> colorlist_9_10

  tibble(colorhex = colorlist_9_10) -> color_hex_grad_9_10

  color_hex_grad_9_10 %>%
    slice(-1) %>%
    mutate(no = NA) %>% #View()
    mutate(no2 = seq(9.05, 10, 0.05)) -> c4


  c3 %>%
    bind_rows(c4) %>%
    rename("val" = "no2") %>%
    dplyr::select(val, colorhex)-> color_hex_ws



  wdat_mean %>%
    dplyr::select(c(x,y,z)) -> dat_sp4

  if(x == y){

    setnames(dat_sp4, c("x", "z"))
    dat_sp4 %>%
      dplyr::select(x,z) %>%
      filter(z >= fil) %>%
      mutate(x11 = z %>% as.numeric() %>% cv_num()) %>%
      rename("val" = "x11") %>%
      left_join(color_hex_ws, by = "val") %>%
      mutate(colorhex = if_else(val < 3, "#79306F", colorhex)) %>%
      mutate(colorhex = if_else(val > 10, "#FFFFFF", colorhex)) %>%
      #filter(val >= 10) -> ddreq
      drop_na()-> ddreq

    ddreq %>%
      ggplot(aes(x = x,
                 y = x)) +
      geom_point(colour = ddreq$colorhex,size = 1) +
      labs(x = xlab,
           y = ylab,
           #title = paste0("Mast Name: ", mast_name1)) +
      title = paste0("Mast Name: ", mast_name1,"\n","WD Sensor vs WD Sensor (color-WS)")) +
      scale_y_continuous(minor_breaks = seq(0,360,5), breaks = seq(0,360,45)) +
      scale_x_continuous(minor_breaks = seq(0,360,5), breaks = seq(0,360,45)) +
      geom_vline(xintercept = seq(0,360,5), alpha = 0.05) +
      geom_vline(xintercept = seq(0,360,45), alpha = 0.1) +
      geom_hline(yintercept = seq(0,360,5), alpha = 0.05) +
      geom_hline(yintercept = seq(0,360,45), alpha = 0.1) +
      expand_limits(x = 0, y = 0) +
      #  ggtitle("WD Sensor vs WD Sensor (color-WS)")+
      labs(color = paste(zlab)) +
      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05)
      )

  } else {

    setnames(dat_sp4, c("x", "y", "z"))

    dat_sp4 %>%
      filter(z >= fil) %>%
      mutate(x11 = z %>% as.numeric() %>% cv_num()) %>%
      rename("val" = "x11") %>%
      left_join(color_hex_ws, by = "val") %>%
      mutate(colorhex = if_else(val < 3, "#79306F", colorhex)) %>%
      mutate(colorhex = if_else(val > 10, "#FFFFFF", colorhex)) %>%
      #filter(val >= 10) -> ddreq
      drop_na() -> ddreq1
    ddreq1 %>%
      ggplot(aes(x = x,
                 y = y)) +
      geom_point(color=ddreq1$colorhex,size = 1) +
      labs(x = xlab,
           y = ylab,
           title = paste0("Mast Name: ", mast_name1)) +
      #title = paste0("Mast Name: ", mast_name1(),"\n","WD Sensor vs WD Sensor (color-WS)")) +
      scale_y_continuous(minor_breaks = seq(0,360,5), breaks = seq(0,360,45)) +
      scale_x_continuous(minor_breaks = seq(0,360,5), breaks = seq(0,360,45)) +
      geom_vline(xintercept = seq(0,360,5), alpha = 0.05) +
      geom_vline(xintercept = seq(0,360,45), alpha = 0.1) +
      geom_hline(yintercept = seq(0,360,5), alpha = 0.05) +
      geom_hline(yintercept = seq(0,360,45), alpha = 0.1) +
      expand_limits(x = 0, y = 0) +
      # ggtitle("WD Sensor vs WD Sensor (color-WS)")+
      labs(color = paste(ddreq1$colorhex)) +
      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05)
      )



  }
  #  p %>%  ggplotly() %>% toWebGL()

}


#scatter plot 5 ----
#' @export
scatter_plot5_func <- function(x,y,winddata_mean,mast_name1) {

  winddata_mean -> wdat
  wdat %>%
    dplyr::select(c(x,y,date_time)) %>% #summary()
    drop_na()  -> int_data_sp6  #getting 3 columns from data and filtering NA
  max(int_data_sp6[1]) %>% round() %>% as.numeric() -> xli
  max(int_data_sp6[2]) %>% round() %>% as.numeric()-> maxval
  min(int_data_sp6[1]) %>% round() %>% as.numeric()-> xlims
  min(int_data_sp6[2]) %>% round()%>% as.numeric() -> minval

  if(maxval-minval < 50){
    maxval1 <- 1.5
    brk1 <- 50
  }else{
    maxval1 <- maxval
    brk1 <- 1
  }

  if(minval < 1.5){
    minval1 <- 1.5
    brk2 <- 0.1
  }else{
    minval1 <- minval
    brk2 <- 0.5
  }

  setnames(int_data_sp6, c('x','y','z') )
  x %>% str_replace_all("_u_00b0_c", " [\u00b0C]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("t", "T")-> tname1

  y %>% str_replace_all("_mbar", " [mbar]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("p", "P") ->pname1
  int_data_sp6 %>%
    mutate(z = as.POSIXct(z,origin = '1900-01-01')) %>%
    mutate(hour = hour(z) ) %>%
    ggplot(aes(x = x,
               y = y,
               colour = hour)) +
    geom_point(size = 1) +
    scale_colour_gradient(low = "lightblue", high = "darkblue") +
    # scale_y_continuous(limits = c(ylims,yli)) +
    # scale_x_continuous(limits = c(xlims,xli)) +
    scale_x_continuous(limits = c(xlims,xli), breaks = seq(xlims,xli,2)) +
    # scale_y_continuous(limits = c(minval,maxval), breaks = seq(minval,maxval,brk1))+
    labs(x = tname1,
         y = pname1,
         color = 'Hour',title = paste0("Mast Name: ", mast_name1,"\n","Pressure vs Temperature(color-Hour)")) +
    # ggtitle("Pressure vs Temperature(color-Hour)")+
    theme(legend.position = "bottom",
          panel.background = element_rect(fill = "white",
                                          color = "black",
                                          size = 1),
          panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
          panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05))  -> p

}

#scatter plot 6 ----
#' @export
scatter_plot6_func <- function(wd,ws1,ws2, winddata_mean,mast_name1,ws_slide_sp) {

  wd %>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD") -> xlab
 paste0(ws1, "/", ws2) %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> ylab

  paste0(wd,"_vs_",ws1, "-",ws2 ) %>% str_replace("/", "-") -> pname

  if(ws1 ==ws2){
    ggplot() +
      labs(title = "Same WS sensors selected")
  } else {

    winddata_mean %>%
    rename("ws_rat1" = ws1,
           "ws_rat2" = ws2,
           "wd" = wd) %>%
    filter(ws_rat1 >= ws_slide_sp, ws_rat2 >= ws_slide_sp) %>%
      mutate(ratio = (ws_rat1/ws_rat2) %>% round(2)) %>%
      ggplot(aes_string(x = "wd",
                        y = "ratio")) +
      geom_point(size = 1) +
      ylim(c(0,2)) +
      scale_x_continuous(minor_breaks = seq(0,360,5), breaks = seq(0,360,45)) +
      geom_vline(xintercept = seq(0,360,5), alpha = 0.05) +
      geom_vline(xintercept = seq(0,360,45), alpha = 0.1) +
      geom_hline(yintercept = seq(0,360,5), alpha = 0.05) +
      geom_hline(yintercept = seq(0,360,45), alpha = 0.1) +
      expand_limits(x = 0, y = 0)+
      labs(x = xlab,
           y = ylab,
           title = paste0("Mast Name: ", mast_name1,"\n","Ratio of Parallel WS Sensors vs WD Sensor")) +
      #   ggtitle("Ratio of Parallel WS Sensors at Same Height vs Primary WD Sensor")+
      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05))-> p

  }

}


#windrose functions ----
#' @export
findbin <- function(x,n){
  v <- seq(0,360, by = 360/n) - (360/(2*n))
  v[1] <- 0
  v[n+2] <- 360
  findInterval(x,v,rightmost.closed = TRUE) -> result
  result[result == (n+1)] <- 1
  return(result)
}

#' @export
wrb1 <- function(n){
  (seq(0,360, by = 360/n) - (360/(2*n))) %>%
    enframe() %>%
    rename(lb = value) %>%
    mutate(ub = lb %>% lead() ) %>%
    mutate(lb = lb)  %>% return()
}

#' @export
wrb2 <- function(n){
  n %>%
    wrb1() %>%
    mutate(lb = (lb + 360) %% 360) %>%
    mutate(ub = ifelse(is.na(ub),360/(2*n),ub)) %>%
    mutate(bin_label = paste0(lb,"-",ub)) %>%
    return()
}


#windrose 1 ----
#' @export
windrose1 <- function(x,df,mast_name1,n,nrow_winddata){

  if(n < 48){
    xsize = 20
  } else if(n < 72) {
    xsize = 13
  } else {
    xsize = 10
  }

 # x <- 'wd_120_mean_u_00b0'
  df %>%
    dplyr::select(x) %>%
    drop_na() %>%
    mutate_at(x, list(ints = ~as.vector(findbin(.,n)))) %>% #View()
    left_join(wrb2(n),by = c("ints"= "name")) %>%
    group_by(bin_label, .drop = FALSE) %>%
    summarise(occ = n()) %>%
    mutate(per=((occ/nrow_winddata)*100) %>% round(2)) %>%
    ungroup() %>%
    rename(wd = bin_label) -> kl1

  if(nrow(kl1) > 1){
    kl1 %>%
      mutate(s = wd) %>%
      separate(s, into = c("a", 'b'), sep = "-") %>% #View()
      mutate(b = b %>% as.numeric()) %>%
      mutate(wd = wd %>% factor() %>% fct_reorder(b)) %>%
      dplyr::select(-c("a", "b")) %>%
      ggplot(aes(x = wd,
                 y = per,
                 fill = per,
                 tooltip = per %>% round(1) %>% paste0("%"),
                 data_id = per)) +
      geom_bar(stat="identity") +
      geom_bar_interactive(stat="identity") +
      coord_polar(start = -(360/(2*n))*pi/180) +
      scale_y_continuous(breaks = seq(0,100,10)) +
      scale_fill_gradient(low = "lightblue", high = "darkblue") +
      labs(x = '',
           y = '',
           title = paste("Mast Name: ", mast_name1),
           # title = paste("Mast Name: ", "mast_name1()","\n","Wind Rose Plot for",
           #               "x" %>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD")),
           fill = "Percentage") +
      #theme_get() +
      theme(axis.title.x = element_blank(),
            axis.text.x = element_text(size = xsize),legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05),
            legend.text = element_text(size = 15),
            legend.title = element_text(size = 28)) +
      scale_x_discrete(labels = paste0(seq(0,360,by = 360/n), "\u00b0"))-> wr
  } else {
    ggplot() +
      labs(title = "No data")  -> wr
  }


  girafe(ggobj = wr,
         width_svg = 25,
         height_svg = 18) %>%
    girafe_options(opts_zoom(max = 4))
  }


#wind rose 2 ----
#' @export
windrose2 <- function(x,df,mast_name1,n,nrow_winddata){
  df %>%
    dplyr::select(c("date_time",x)) %>%
    mutate(month = date_time %>% lubridate::month(label = T)) %>%
    drop_na() %>%
    mutate_at(x, list(ints = ~as.vector(findbin(.,n)))) %>%
    left_join(wrb2(n),by = c("ints"= "name")) %>%
    group_by(bin_label, month) %>%
    summarise(occ = n()) %>%
    mutate(per=((occ/nrow_winddata)*100) %>% round(2)) %>%
    ungroup() %>%
    rename(wd = bin_label) -> kl1

  if(nrow(kl1) > 1) {
    kl1 %>%
      mutate(s = wd) %>%
      separate(s, into = c("a", 'b'), sep = "-") %>% #View()
      mutate(b = b %>% as.numeric()) %>%
      mutate(wd = wd %>% factor() %>% fct_reorder(b)) %>%
      dplyr::select(-c("a", "b")) %>%
      ggplot(aes(x = wd,
                 y = per,
                 fill = per,
                 tooltip = per %>% round(1) %>% paste0("%"),
                 data_id = per)) +
      geom_bar(stat="identity") +
      geom_bar_interactive(stat="identity") +
      coord_polar(start = -(360/(2*n))*pi/180) +
      scale_y_continuous(breaks = seq(0,100,10)) +
      scale_fill_gradient(low = "lightblue", high = "darkblue") +
      facet_wrap(~month, ncol = 4) +
      labs(x = '',
           y = '',
           title = paste("Mast Name: ", mast_name1),
           # title = paste("Mast Name: ", mast_name1,"\n","Wind Rose Montly Plot "
           #               %>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD")),
           fill = "Percentage") +
      #theme_get() +
      theme(axis.title.x = element_blank(),
            axis.text.x = element_text(size = 10),legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05),
            legend.text = element_text(size = 15),
            legend.title = element_text(size = 25)) +
      scale_x_discrete(labels = paste0(seq(0,360,by = 360/n), "\u00b0"))-> wr
  } else {
    ggplot() +
      labs(title = "No data") -> wr
  }


    girafe(ggobj = wr,
           width_svg = 12,
           height_svg = 10) %>%
    girafe_options(opts_zoom(max = 8))
}


#wind rose 3 ----
#' @export
windrose3 <- function(x,df,mast_name1,n,nrow_winddata){
  df %>%
    dplyr::select(c("date_time",x)) %>%
    mutate(month = date_time %>% lubridate::month(label = T)) %>%
    drop_na() %>%
    mutate_at(x, list(ints = ~as.vector(findbin(.,n)))) %>%
    left_join(wrb2(n),by = c("ints"= "name")) %>%
    group_by(bin_label, month) %>%
    summarise(occ = n()) %>%
    mutate(per=((occ/nrow_winddata)*100) %>% round(2)) %>%
    ungroup() %>%
    rename(wd = bin_label) -> kl1

  if(nrow(kl1) > 1){
    kl1 %>%
      mutate(s = wd) %>%
      separate(s, into = c("a", 'b'), sep = "-") %>% #View()
      mutate(b = b %>% as.numeric()) %>%
      mutate(wd = wd %>% factor() %>% fct_reorder(b)) %>%
      dplyr::select(-c("a", "b")) %>%
      ggplot(aes(x = wd,
                 y = per,
                 fill = per,
                 tooltip = per %>% round(1) %>% paste0("%"),
                 data_id = per)) +
      geom_bar(stat="identity") +
      geom_bar_interactive(stat="identity") +
      coord_polar(start = -(360/(2*n))*pi/180) +
      scale_y_continuous(breaks = seq(0,100,10)) +
      scale_fill_gradient(low = "lightblue", high = "darkblue") +
      facet_wrap(~month, ncol = 4) +
      labs(x = '',
           y = '',
           title = paste("Mast Name: ", mast_name1,"\n","Wind Rose Montly Plot "
                         %>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD")),
           fill = "Percentage") +
      #theme_get() +
      theme(axis.title.x = element_blank(),
            axis.text.x = element_text(size = 10),legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05),
            legend.text = element_text(size = 16),
            legend.title = element_text(size = 25)) -> wr
  } else {
    ggplot() +
      labs(title = "No Data") -> wr
  }

    #scale_x_discrete(labels = paste0(seq(0,360,by = 360/n), "\u00b0"))-> wr
  girafe(ggobj = wr) %>%
    girafe_options(opts_zoom(max = 4))
}
#wind rose 4 ----
#' @export
windrose4 <- function(x,y,winddata_mean,mast_name1,n){
   # x <- "ws_120_mean_m_s"
   # y <- "wd_120_mean_u_00b0"

  winddata_mean %>%
    rename("v1" = x) -> wdat1
  wdat1 %>% rename("v2"=y)->wdat2
  wdat2 %>% #names
    dplyr::select(v1,v2) %>%
    mutate_at("v2", list(ints = ~as.vector(findbin(.,n)))) %>%
    left_join(wrb2(n),by = c("ints"= "name")) %>% #View()
   drop_na() -> wdp11

  if(nrow(wdp11) > 1){
    wdp11 %>% dplyr::select(bin_label) %>% group_by(bin_label) %>% unique() -> wdca
    nrow(wdca)->nwdca

    wsre1 <- data.frame(matrix(nrow = nwdca, ncol = 4))
    colnames(wsre1) <- c("i", "wd_value","sum","Avg")
    for(i in 1:nwdca)
    {
      wdp11 %>%
        dplyr::select(bin_label,v1) %>%
        group_by(bin_label, .drop = FALSE) %>%
        summarise(Avg = v1 %>% mean(na.rm = T)) -> asc2
    }

    asc2 %>%
      mutate(s = bin_label) %>%
      separate(s, into = c("a", 'b'), sep = "-") %>% #View()
      mutate(b = b %>% as.numeric()) %>%
      mutate(bin_label = bin_label %>% factor() %>% fct_reorder(b)) %>%
      dplyr::select(-c("a", "b")) %>%
      ggplot(aes(x = bin_label,
                 y = Avg,
                 fill = Avg,
                 tooltip = Avg %>% round(1) %>% paste0("%"),
                 data_id = Avg)) +
      geom_bar(stat="identity") +
      geom_bar_interactive(stat="identity") +
      coord_polar(start = -(360/(2*n))*pi/180) +
      #scale_y_continuous(breaks = seq(0,100,10)) +
      scale_fill_gradient(low = "lightblue", high = "darkblue") +
      labs(x = '',
           y = '',
           title = paste("Mast Name: ", mast_name1),
           # title = paste("Mast Name: ", "mast_name1()","\n","Wind Rose Plot for",
           #               "x" %>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD")),
           fill = "Percentage") +
      #theme_get() +
      theme(axis.title.x = element_blank(),
            axis.text.x = element_text(size = 10),legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05),
            legend.text = element_text(size = 16),
            legend.title = element_text(size = 25)) +
      scale_x_discrete(labels = paste0(seq(0,360,by = 360/n), "\u00b0")) -> wr
  } else {
    ggplot() +
      labs(title = "No Data") -> wr
  }


  girafe(ggobj = wr,
         width_svg = 15,
         height_svg = 12) %>%
    girafe_options(opts_zoom(max = 4))

}

#windrose 5 ----
#' @export
windrose5 <- function(x,y,winddata_mean,mast_name1){
  # x <- "ws_120__mean_m_s"
  # y <- "wd_120_mean_u_00b0"
  winddata_mean %>%
    rename("v1" = x) -> wdat1
  wdat1 %>% rename("v2"=y)-> wdat2
  wdat2 %>% #names
    dplyr::select(v1,v2) %>%
    mutate(y1 = case_when(v2   > 0 & v2   <= 11.25 ~ '348.75-11.25_1' ,
                          v2   > 11.25 & v2   <= 33.75 ~ "11.25-33.75_2",
                          v2   > 33.75 & v2   <= 56.25 ~ "33.75-56.25_3",
                          v2   > 56.25 & v2   <= 78.75 ~ "56.25-78.75_4",
                          v2   > 78.75 & v2   <= 101.25 ~ "78.75-101.25_5",
                          v2   > 101.25 & v2   <= 123.75 ~ "101.25-123.75_6",
                          v2   > 123.75 & v2   <= 146.25 ~ "123.75-146.25_7",
                          v2   > 146.25 & v2   <= 168.75 ~ "146.25-168.75_8",
                          v2   > 168.75 & v2   <= 191.25 ~ "168.75-191.25_9",
                          v2   > 191.25 & v2   <= 213.75 ~ "191.25-213.75_10",
                          v2   > 213.75 & v2   <= 236.25 ~ "213.75-236.25_11",
                          v2   > 236.25 & v2   <= 258.75 ~ "236.25-258.75_12",
                          v2   > 258.75 & v2   <= 281.25 ~ "258.75-281.25_13",
                          v2   > 281.25 & v2   <= 303.75 ~ "281.25-303.75_14",
                          v2   > 303.75 & v2   <= 326.25 ~ "303.75-326.25_15",
                          v2   > 326.25 & v2   <= 348.75 ~ "326.25-348.75_16",
                          v2   > 348.75 & v2   <= 360 ~ '348.75-11.25_1'))  %>%
    drop_na() -> wdp11

  if(nrow(wdp11) > 1){
    wdp11 %>% dplyr::select(y1) %>% group_by(y1) %>% unique() ->wdca
    nrow(wdca)->nwdca

    wsre1 <- data.frame(matrix(nrow = nwdca, ncol = 4))
    colnames(wsre1) <- c("i", "wd_value","sum","Avg")
    for(i in 1:nwdca)
    {
      wdp11 %>%
        dplyr::select(y1,v1) %>%
        group_by(y1) %>%
        summarise(Avg = v1 %>% mean()) -> asc2
    }

    #asc2 <- wsre1[with(wsre1, order(wd_value)), ]
    asc2 %>%
      bind_rows(tibble(y1 =  c("348.75-11.25_1","11.25-33.75_2","33.75-56.25_3","56.25-78.75_4", "78.75-101.25_5","101.25-123.75_6",
                               "123.75-146.25_7", "146.25-168.75_8", "168.75-191.25_9","191.25-213.75_10",
                               "213.75-236.25_11", "236.25-258.75_12", "258.75-281.25_13", "281.25-303.75_14",
                               "303.75-326.25_15", "326.25-348.75_16")) %>% mutate(Avg = 0)) %>%
      ggplot(aes(x = y1 %>% factor(levels = c("348.75-11.25_1","11.25-33.75_2","33.75-56.25_3","56.25-78.75_4", "78.75-101.25_5","101.25-123.75_6",
                                              "123.75-146.25_7", "146.25-168.75_8", "168.75-191.25_9","191.25-213.75_10",
                                              "213.75-236.25_11", "236.25-258.75_12", "258.75-281.25_13", "281.25-303.75_14",
                                              "303.75-326.25_15", "326.25-348.75_16")),
                 y = Avg %>% round(1),
                 fill = Avg,
                 tooltip = Avg %>% round(1) %>% paste0("%"),
                 data_id = Avg)) +
      geom_bar(stat="identity") +geom_bar_interactive(stat="identity")+

      coord_polar(start = -0.2) +
      scale_fill_gradient(low = "lightblue", high = "darkblue") +
      labs(x = '',
           y = '',
           title = paste("Mast Name: ", mast_name1),
           # title = paste("Mast Name: ", mast_name1,"\n","Wind Rose Plot \n Average of",x%>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS"), "per Direction for", y%>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD")),
           fill = "Average Wind Speed") +
      #theme_get() +
      theme(axis.title.x = element_blank(),
            axis.text.x = element_text(size = 10),
            legend.position = "none",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05),
            legend.text = element_text(size = 16),
            legend.title = element_text(size = 25))+
      scale_x_discrete(labels = paste0(c(0.0,22.5,45,67.5, 90,112.5,
                                         135, 157.5, 180,202.5,
                                         225, 247.5, 270, 292.5,
                                         315, 337.5), "\u00b0"))-> wr4
  } else {
    ggplot() +
      labs(title = "No Data") -> wr4
  }



  girafe(ggobj = wr4,
         width_svg = 15,
         height_svg = 12) %>%
    girafe_options(opts_zoom(max = 4))
}

  #' @export
  find_turb <- function(x){
    regexp <- "[[:digit:]]+"
    tibble(m = x) %>%
      mutate(l1 = m %>% str_detect("ws")) %>%
      filter( l1== T) %>%
      mutate(l2 = m %>% str_detect("turb")) %>%
      filter( l2== T) %>%
      mutate(dig = m %>% str_extract(regexp) %>% as.numeric()) %>%
      mutate(l3 = m %>% str_detect("_a_|_b_|_c_|_d_|_e_|_n_|_s_|_ne_|_nw_|_se_|_sw_|_e_|_w_|_nne_|_nnw_|_sse_|_ssw_")) %>%
      filter(l3 == F) %>%
      arrange(desc(dig)) %>%
      slice(1) %>%
      dplyr::select(m) %>%
      pull() -> turbcols
  }

















#frequency distribution1 ----
#' @export
freq_dist1_fun <- function(x,winddata_mean,mast_name1, bin_width){

 winddata_mean -> wdat_1
  wdat_1 %>%
    rename("var1" = x) ->wdat4
  wdat4 %>%
    dplyr::select(var1) %>%
    filter(var1 > 0) %>%
    drop_na() -> fdn

  fit_w  <- fitdist(fdn$var1, "weibull")
  # fit_w
  # Fitting of the distribution ' weibull ' by maximum likelihood
  # Parameters:
  #   estimate Std. Error
  # shape 2.547675 0.01087829
  # scale 8.019905 0.01840045
  fit_w$estimate[1] %>% round(1)->w_1
  fit_w$estimate[2] %>% round(1)->w_2
  # xwei <- rweibull(wdat4$var1, shape = fit_w$estimate[1], scale = fit_w$estimate[2])

  xwei <- rweibull(fdn$var1, shape = fit_w$estimate[1], scale = fit_w$estimate[2])
  xwei %>% as.data.frame() ->xwei
  xwei %>% filter(xwei[1]>0.3) ->xwei
  xwei$. %>% as.numeric() ->xwei
  den1 <- density(xwei)
  datwe <- data.frame(x = den1$x, y = den1$y)
  datwe <- datwe  %>% filter(x> 0)
  fit.params <- fitdistr(xwei, "weibull",lower = c(0, 0))

  #https://www.statisticshowto.datasciencecentral.com/choose-bin-sizes-statistics/
  unique(fdn$var1) ->fdn1
  bin <- 1 + (3.322*log10(length(fdn1)))
  #or
  nrow(fdn)->Ntotcount
  bin <- 1 + (3.322*log10(Ntotcount))
  #or
  max(fdn$var1)->max1
  max1/bin -> binsize
  #or
  bin_width
  #isolate(input$bin_width)
  max(fdn$var1)->max1
  min(fdn$var1)->min1
  Number_of_bins <- (max1-min1)/bin_width
  #https://www.qimacros.com/histogram-excel/how-to-determine-histogram-bin-interval/
  bin1 <- sqrt(Ntotcount)
  binwidth1 <- (max1-min1)/as.numeric(bin1)
  #https://www.fmrib.ox.ac.uk/datasets/techrep/tr00mj2/tr00mj2/node24.html
  sd(fdn$var1, na.rm = FALSE)->std
  `^`(Ntotcount,(-1/3))->std1
  3.49*std*std1 ->binwidth3
  #3.49??n???1/3.
  #https://stats.stackexchange.com/questions/798/calculating-optimal-number-of-bins-in-a-histogram
  bw <- 2 * IQR(fdn$var1) / length(fdn$var1)^(1/3)
  numberofbins = ((max1-min1)/ bw )
  #or
  bw <- 2 * IQR(xwei / length(xwei)^(1/3))
  numberofbins = ((max1-min1)/ bw )

  #used
  max(xwei)->max11
  min(xwei)->min11
  Number_of_bins1 <- (max11-min11)/ bin_width

  x %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") ->xpp

  ggplot() +
    geom_histogram(data = as.data.frame(xwei),
                   aes(x=xwei, (y=..density..)),bins=  Number_of_bins1 ,fill = "brown", col = "black",binwidth = bin_width)+
    geom_line(aes(x=datwe$x, y=dweibull(datwe$x,fit.params$estimate["shape"],
                                        fit.params$estimate["scale"])), color="black", size = 1) +
    labs(x=xpp, y = "Density",title = paste0("Mast Name: ", mast_name1,"\n","Primary WS Sensor Frequency Distribution","\n","Weibull distribution:k =",w_1,","," A = ",w_2))+
    #ggtitle("Primary WS Sensor Frequency Distribution", subtitle= paste0("Weibull distribution:k = ",w_1,","," A = ",w_2))+
    # ggtitle(paste0("Primary WS Sensor Frequency Distribution \n Weibull distribution:k = ",w_1,","," A = ",w_2))+
    scale_color_manual(name = "",
                       values = c("brown", "black"),
                       labels = c("Actual Data", "Weibull Distribution"))+
    scale_x_continuous(breaks=seq(0, 25, 1))+
    geom_vline(xintercept = seq(0,24,0.2), alpha = 0.05) +
    geom_vline(xintercept = seq(0,24,1), alpha = 0.1) +
    theme(legend.position = "bottom",
          panel.background = element_rect(fill = "white",
                                          color = "black",
                                          size = 1),
          panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
          panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05))-> p

  p %>% ggplotly() %>% toWebGL()

}



#frequency dist2 & dist3----
#' @export
freq_dist234_fun <- function(x,winddata_mean,mast_name1) {

  winddata_mean %>%
    #wdat_1 %>%
    #mutate(date_time = date_time %>% as_datetime(origin = lubridate::origin)) %>%
    mutate(timestamp=ymd_hms(date_time)) %>%
    mutate(year = timestamp %>% year()) %>%
    mutate(month = timestamp %>% month())-> wdat1
  wdat1 %>%
    rename("var1" = x)->wdat1

  wdat1 %>%
    dplyr::select("month") %>% group_by(month) %>% unique() ->yr_1

  nrow(yr_1) -> rr
  wdat1 %>%
    dplyr::select("var1") %>% filter(var1 !=9999) %>% unique() ->mo
  mo %>% round(0) %>%  unique()->mo11
  nrow(mo11) ->mo1

  remo1 <- data.frame(matrix(nrow = mo1, ncol = 5))
  colnames(remo1) <- c("i", "month","count","Temp values","per")
  beta<-data.frame(matrix(NA, nrow = mo1, ncol = 1))[-1]
  for(i in 1:rr)
  {
    for(j in 1:mo1)
    {
      wdat1  %>% dplyr::select("month","var1") %>% filter(month %>% as.numeric() == yr_1[i,1] %>% as.numeric()) -> r
      r  %>% dplyr::select(var1) -> r1
      r1 %>% round(0) -> r2
      r2 %>% filter( r2$var1 == mo11$var1[j]) ->si
      nrow(r) %>% as.numeric() ->roo
      nrow(si) %>% as.numeric() -> si1
      ((si1/roo)*100) %>% round(0)  -> per
      remo1[j, 1] <- j
      remo1[j, 2] <- yr_1[i,1] %>% as.numeric()
      remo1[j, 3] <- si1
      remo1[j, 4] <- mo11$var1[j]
      remo1[j, 5] <- per
    }
    beta <- rbind(beta, remo1)
  }
  colnames(beta) <- make.names(colnames(beta), unique = TRUE)
  beta %>% as.data.frame() %>% clean_names() ->beta2
  #####over all data
  remo <- data.frame(matrix(nrow = mo1, ncol = 5))
  remo %>% mutate( Line_size = "overall") -> remo
  colnames(remo) <- c("i", "count","temp_values","per", "month","Line_size")

  for(i in 1:mo1)
  {
    wdat1 %>% dplyr::select("var1") -> rd1
    rd1 %>% round(0) -> rd2
    rd2 %>% filter( rd2$var1 == mo11$var1[i]) ->si
    nrow(rd1) %>% as.numeric() ->roo
    nrow(si) %>% as.numeric() -> si1
    ((si1/roo)*100) %>% round(0)  -> per
    remo[i, 1] <- i
    remo[i, 2] <- si1
    remo[i, 3] <- mo11$var1[i]
    remo[i, 4] <- per
  }

  rbind(beta2 %>%
          dplyr::select(i, count, temp_values, per, month)%>%
          mutate(Line_size = "Month"),remo) %>% as.data.frame()->m
  m[5][is.na(m[5])] <- as.character(m[6][is.na(m[5])])
  m %>% mutate(mon = month)->m
  m %>% arrange(mon) ->m
  m[5] <- replace(m[5],m[5]==1, "Jan")
  m[5] <- replace(m[5],m[5]==2, "Feb")
  m[5] <- replace(m[5],m[5]==3, "Mar")
  m[5] <- replace(m[5],m[5]==4, "Apr")
  m[5] <- replace(m[5],m[5]==5, "May")
  m[5] <- replace(m[5],m[5]==6, "Jun")
  m[5] <- replace(m[5],m[5]==7, "Jul")
  m[5] <- replace(m[5],m[5]==8, "Aug")
  m[5] <- replace(m[5],m[5]==9, "Sep")
  m[5] <- replace(m[5],m[5]==10, "Oct")
  m[5] <- replace(m[5],m[5]==11, "Nov")
  m[5] <- replace(m[5],m[5]==12, "Dec")
  m[6] <- replace(m[6],m[6]=="Month", 0.5)
  m[6] <- replace(m[6],m[6]=="overall",2)
  m %>% arrange(mon) ->m
  m %>% dplyr::select(month)  -> mmname
  factor(mmname$month,levels = c("Jan", "Feb", "Mar","Apr", "May", "Jun","Jul", "Aug", "Sep","Oct", "Nov", "Dec","overall")) -> Month


  x %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_u_00b0_c", " [\u00b0C]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") %>% str_replace_all ("t", "T") %>%   str_replace_all("mbar", " [mbar]") %>% str_replace_all ("p", "P")-> namex11



  m %>%
    dplyr::select(-mon) %>%
    ggplot(aes(x = temp_values,
               y= per,color= Month))+

    geom_line(aes(alpha =0.3),size=m$Line_size %>% as.numeric())+

    labs(x= namex11, y = "Frequency(%)",title = paste0("Mast Name: ", mast_name1,"\n","Frequency by Month of Year"))+
    #scale_x_continuous(limits=c(0,24), breaks=seq(0,24,1))+
    scale_y_continuous(limits=c(0,100),breaks=seq(0,100,10))+
    #geom_vline(xintercept = seq(0,24,0.2), alpha = 0.05) +
    #geom_vline(xintercept = seq(0,24,1), alpha = 0.1) +
    #  ggtitle("Frequency by Month of Year")+
    scale_alpha(guide = 'none')+
    theme(legend.position = "bottom",
          panel.background = element_rect(fill = "white",
                                          color = "black",
                                          size = 1),
          panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
          panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05))-> p
  #  scale_size_discrete(guide = 'none')

  p %>% ggplotly() %>% layout(legend = list(
    orientation = "h",
    x = 0,
    y = -0.2
  )) %>% toWebGL()
}



#diurnal plot 1 ----
  #' @export
dinu1_fun <-  function(dri,winddata_mean,mast_name1){

  winddata_mean -> wdat_1
  wdat_1 %>% colnames() -> cn1
  wdat_1 %>%
    # mutate(date_time = date_time %>% as_datetime(origin = lubridate::origin)) %>%
    mutate(timestamp=ymd_hms(date_time)) %>%
    mutate(year = timestamp %>% year()) %>%
    mutate(month = timestamp %>% month()) %>%
    mutate(date = timestamp %>% date()) %>%
    mutate(day = timestamp %>% day()) %>%
    mutate(hour = timestamp %>% hour()) -> wdat1

  regexp <- "[[:digit:]]+"
  tibble(x = cn1) %>%
    mutate(l1 = x %>% str_detect("ws|vws")) %>%
    filter(l1 == T) %>%
    mutate(dig = x %>% str_extract(regexp) %>% as.numeric()) %>%
    group_by(dig) %>%
    mutate(count = n()) %>%
    mutate(l2 = x %>% str_detect("_a_|_b_|_n_|_s_|_nw_|_se_")) %>%
    filter(l2 == F | count ==1) %>%
    mutate(l3 = x %>% str_detect("sd|min|max")) %>%
    filter(l3 == F) %>%
    pull(x) -> subsetcols

  min(wdat1$date)->mindate
  max(wdat1$date)->maxdate

 dri -> dtt

  format(strptime(dtt[1], format = "%Y-%m-%d")) -> sddt1
  format(strptime(dtt[2], format = "%Y-%m-%d")) -> eddt11

  sddt1 %>% as.Date() -> sddt11
  eddt11 %>% as.Date() -> eddt111

  if (isTRUE(sddt11 >=mindate & eddt111 <= maxdate)){
    wdat1 %>%
      dplyr::select(date_time,hour,date,subsetcols) %>%
      filter(date >= sddt11, date <= eddt111)-> subsetdat
      ncol(subsetdat) %>% as.numeric()  -> gathnum

      subsetdat %>% gather(key = "Sensors1", value = "Values", c(4:gathnum)) %>%  group_by(hour, Sensors1)%>%
      summarise(hourly_mean = mean(Values,trim=0, na.rm = TRUE)) -> Hourly

    #Hourly$Sensors %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> Sensor
    Hourly %>% mutate(Sensors=Sensors1 %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS"))->Hourly
    ggplot(data = Hourly,aes(x = hour,
                             y = hourly_mean,
                             color = Sensors)) +
      geom_line(aes(group = Sensors)) + labs(y = "Mean Wind Speed (m/s)",
                                             x = "Hour of Day",
                                             title = paste0("Mast Name: ", mast_name1,"\n","Wind Speed Diurnal Variation"))+
     scale_x_continuous(breaks=seq(0, 23, 3))+
      #scale_y_continuous(limits=c(0,24),breaks=seq(0, 24, 1))+
     # geom_hline(yintercept = seq(0,24,0.2), alpha = 0.05) +
    #  geom_hline(yintercept = seq(0,24,1), alpha = 0.1) +
      # geom_vline(yintercept = seq(0,24,0.2), alpha = 0.05) +
      # geom_vline(yintercept = seq(0,24,1), alpha = 0.1) +

      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05)) -> p

    p %>% ggplotly() %>% layout(legend = list(
      orientation = "h",
      x = 0,
      y = -0.2)) %>%  toWebGL()

    # p %>% ggplotly() %>% toWebGL() -> pp
    # return(pp)

  } else if(sddt11 < mindate | sddt11 > maxdate | sddt11 > mindate | sddt11 < maxdate  & is.na(eddt11)){
    ggplot() +
      labs(title = "Please choose the valid dates")
  }else{
    ggplot() +
      labs(title = "Please choose the valid dates")
  }
}

#diurnal plot 2 ----
  #' @export
dinu2_fun <-  function(wdat,mast_name1){
 #winddata_mean ->> wdat
  wdat
  compute_ratio_columns <- function(x,y){

    paste0(x,"/",y) -> z

    wdat %>%
      rename("var1" = x,
             "var2" = y) %>%
      mutate(z = (var1/var2) %>% round(2)) %>%
      dplyr::select(z) -> newcol

    colnames(newcol) <- z

    wdat %>% bind_cols(newcol) ->> wdat
  }
  regexp <- "[[:digit:]]+"
  wdat %>% colnames()-> cn1
  tibble(m = cn1) %>%
    mutate(l1 = m %>% str_detect("ws")) %>%
    filter( l1== T) %>%
    mutate(l2 = m %>% str_detect("mean")) %>%
    filter( l2== T) %>%
    mutate(dig = m %>% str_extract(regexp) %>% as.numeric()) %>%
    mutate(l3 = m %>% str_detect("_a_|_b_|_n_|_s_|_nw_|_se_|_ne_|_sw_")) %>%
    filter(l3 == F) %>%
    arrange(desc(dig)) %>%
    slice(1) %>%
    pull(m) -> dinural_highest_sensor
  tibble(m = cn1) %>%
    mutate(l1 = m %>% str_detect("ws")) %>%
    filter( l1== T) %>%
    mutate(l2 = m %>% str_detect("mean")) %>%
    filter( l2== T) %>%
    mutate(dig = m %>% str_extract(regexp) %>% as.numeric()) %>%
    mutate(l3 = m %>% str_detect("_a_|_b_|_n_|_s_|_nw_|_se_|_ne_|_sw_")) %>%
    filter(l3 == F) %>%
    arrange(desc(dig)) %>%
    mutate(m1 = dinural_highest_sensor) %>%
    dplyr::select(m,m1) %>%
    slice(-1) %>%
    mutate(di = pmap(list(m1,m),compute_ratio_columns))

  wdat %>% names() -> cn_d2
  tibble(x = cn_d2) %>%
    mutate(l1 = x %>% str_detect("/")) %>%
    filter( l1== T) %>%
    mutate(l2 = x %>% str_detect("mean")) %>%
    filter( l2== T) %>%  pull(x)->subsetcols1

  wdat %>%
    # mutate(date_time = date_time %>% as_datetime(origin = lubridate::origin)) %>%
    mutate(timestamp=ymd_hms(date_time)) %>%
    mutate(year = timestamp %>% year()) %>%
    mutate(month = timestamp %>% month()) %>%
    mutate(day = timestamp %>% day()) %>%
    mutate(hour = timestamp %>% hour()) -> wdatm

  subsetcols1 %>% length()-> len
  if(len > 0){
    wdatm %>%
      dplyr::select(date_time,hour, subsetcols1)  -> subsetdat1

    ncol(subsetdat1) %>% as.numeric()  -> gathnum1


    subsetdat1 %>% gather(key = "Sensors1", value = "Values", c(3:gathnum1)) %>%  group_by(hour, Sensors1)%>%
      summarise(hourly_mean = mean(Values,trim=0, na.rm = TRUE)) -> Hourly
    Hourly %>% mutate(Sensors=Sensors1 %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS"))->Hourly
    #  Hourly$Sensors %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> Sensor


    ggplot(data = Hourly,aes(x = hour,
                             y = hourly_mean,
                             color = Sensors)) +
      geom_line(aes(group = Sensors)) + labs(y="Ratio of WS Mean(m/s)",
                                             x="Hour of Day",
                                             title = paste0("Mast Name: ", mast_name1,"\n","Diurnal Variation- (WS Ratio of Sensors at Different Height)"))+
      scale_x_continuous(breaks=seq(0, 23, 3))+
      #scale_y_continuous(limits=c(0,24),breaks=seq(0, 24, 1))+
      # geom_vline(yintercept = seq(0,24,0.2), alpha = 0.05) +
      # geom_vline(yintercept = seq(0,24,1), alpha = 0.1) +
      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05))->du2

    du2 %>% ggplotly() %>% layout(legend = list(
      orientation = "h",
      x = 0,
      y = -0.2
    )) %>%  toWebGL()
    # du2 %>% ggplotly() %>% toWebGL() -> pp

  }

  #  return(pp)

}


#Histogram ----
  #' @export
histogram_plot_func <- function(x,y,winddata_mean,mast_name1,bin_width1,bin_width2){
  xl <- x
  yl <- y

  winddata_mean -> wdat_1
  wdat_1 %>%
    rename("v1" = x) -> wdat1
  wdat1 %>% rename("v2"=y)->wdat2
  wdat2 %>% dplyr::select("v1","v2") -> am

  am %>%
    filter(v1 != 5005) %>%
    filter(v2 != 9999) %>%
    filter(!is.na(v2 ))  -> am1
  am1 %>% as.data.frame() -> am1
  bin_size <- 1
  bin_size1 <- 10
  xbins <- (max(am1$v1) - min(am1$v1))/bin_size
  ybins <- (max(am1$v2) - min(am1$v2))/bin_size1

  xname1 <- list(
    title = xl %>% str_replace_all("_m_s", " [m/s]") %>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS")
    # titlefont = f
  )
  yname1 <- list(
    title = yl %>% str_replace_all("_u_00b0", " [\u00b0]")%>% str_replace_all("_", "") %>% str_replace_all("mean", " Mean") %>% str_replace_all ("wd", " WD"),
    autotick = F, tickmode = "array", tickvals = c(0,45,90,135,180,225,270,315,360)

    #titlefont = f
  )

  Count <- with(am1, table(v1, v2))
  tval <- c(0,45,90,135,180,225,270,315,360) #generates a sequence of numbers in logarithmic divisions
  ttxt <- rep("",length(tval))  # no label at most of the ticks
  ttxt[seq(0,360,5)] <- as.character(tval)[seq(0,360,5)] # every 9th tick is labelled


  #   p <- plot_ly(am1, x = ~v1, y = ~v2, z = ~ Count,nbinsx = isolate(input$bin_width1),nbinsy = isolate(input$bin_width2)) %>%
  p <- plot_ly(am1, x = ~v1, y = ~v2, z = ~ Count,xbins = list(2,bin_width1,50),nbinsy = bin_width2,nbinsx = bin_width1) %>%
    add_histogram2d() %>%
    layout(annotations =
             list(x = xl, y = yl, text = paste0(mast_name1,"- Histogram plot of Primary WS Sensor vs WD Sensor"),
                  showarrow = F, xref='paper', yref='paper',
                  xanchor='right', yanchor='auto', xshift=0, yshift=0,
                  font=list(size=15, color="black"))
    ) %>%
    layout(xaxis = xname1, yaxis = yname1)

  return(p)


}

#sheltering ratio ------
  #' @export
shelter_plot_func <- function(x,y,winddata_shelter,ws_slide_shel_density,mast_name1){


  # winddata_ratio() -> wdat_1
  winddata_shelter -> wdat_shel

  wdat_shel %>%
    dplyr::select(x,y) %>%
    round(2)  -> oo
  oo -> oo1
  colnames(oo1) <- c('wd','WS_ratio')
  ##########Sheltering ratio with plotly
  plot_ly(data = oo1,
          r = ~WS_ratio,
          theta = ~wd,
          #color = ~WS_ratio,
          color = 'red',
          alpha = ws_slide_shel_density,
          # direction = 'anticlockwise',
          mode = 'markers', type = 'scatterpolar') %>%
    layout(
      title = paste0(mast_name1,"- Sheltering Ratio - WS Sensors Ratio at Same Height"),
      margin = list(l = 100), yaxis=list(tickprefix=""),
      polar = list(
        angularaxis = list(
          tickfont = list(
            size = 8
          ),
          rotation = 90,
          direction = 'clockwise'
        )
      )
    )
}

#annual Average ----
  #' @export
  annual_fun <- function(primary,winddata_mean,mast_name1){
    winddata_mean -> wdat_mean
    wdat_mean %>%
      dplyr::select(c(primary, date_time)) %>%
      drop_na() -> int_data

    nrow(int_data) -> ffma
    #14832

    colnames(int_data) <- c('x','z')

    primary %>% str_replace_all("_m_s", " [m/s]") %>%
      str_replace_all("_", "") %>%
      str_replace_all("mean", " Mean") %>% str_replace_all ("ws", " WS") -> xlab

    int_data %>%
      mutate(z = as.POSIXct(z,origin = '1900-01-01')) %>%
      mutate(year = year(z) ) %>%
      mutate(year = year %>% as.character()) %>%
      group_by(year) %>%
      summarise(x=mean(x)) -> llll
    max(llll$x) -> li
    #  summarise(x = sum(x)/ffma) %>%
    llll %>%
      ggplot(aes(x = year,
                 y = x)) +
      geom_col(aes(fill = year),width = 0.3)+
      # geom_line()+
      #facet_wrap(~sensor_type,scales = 'free', ncol = 1) +
      scale_y_continuous(limits=c(0,li), breaks=seq(0,li,0.5))+
      theme(legend.position = "none") +
      labs(
        #  subtitle = paste('Sensor height:', cols_ws_primary %>% str_extract(regexp)),
        x = 'Year',
        y = xlab,title = paste0("Mast Name: ", mast_name1,"\n","Annual average of wind speed"))+
      theme(legend.position = "bottom",
            panel.background = element_rect(fill = "white",
                                            color = "black",
                                            size = 1),
            panel.grid.major = element_line(color = "#f1f1f1", size = 0.3),
            panel.grid.minor = element_line(color = "#f1f1f1", size = 0.05)) -> p
    p %>% ggplotly() %>% toWebGL()
  }

  #' @export
  get_predictions_from_models2 <- function(x,models){
    f1 <- function(x_vec,model,n){
      tibble(x = x_vec) %>%
        tidypredict_to_column(model)
    }

    f2 <- function(n){
      x %>%
        f1(models[[n]],n)
    }

    f3 <- function(){
      1:length(models) %>%
        map(f2)
    }

    f3()
  }

  #' @export
  get_nearest_height_val <- function(hts,sensor_hts){
    hts <- hts %>% as.numeric()
    sensor_hts %>%
      enframe(value = "heights") %>%
      mutate(heights = heights %>% as.numeric()) %>%
      mutate(diff = (heights - hts) %>% abs()) %>%
      arrange(diff) %>%
      slice(1) %>%
      pull(heights)
  }

  lookup_sensor_colname <- function(input.select_height, df){
    df %>%
      filter(input_heights == input.select_height) %>%
      slice(1) %>%
      pull(nearest_override_sensor_heights_colname)
  }



  #' @export
  add_col_to_df <- function(n, df, col, mh, apha_col) {
    varname <- paste("ws_pl", n,"m_s",sep="_" )
    df[[varname]] <- df[[col]] * (n/mh) ^ df[[apha_col]]
    df %>%
      select(all_of(varname))
  }

  #' @export
  add_col_to_df_log_law <- function(h, df,u_star_col,z0_col) {
    varname <- paste("ws_ll",h,"m_s",sep="_" )
    df[[varname]] <- (1/0.4) * df[[u_star_col]] * log(h/df[[z0_col]])
    df %>%
      select(all_of(varname))
  }

  # inputs : sensor table
  # outputs : height of the max anemometer
  get_max_height <- function(st){
    st %>%
      pull(ht) %>%
      max()
  }

  # input : a set of sensors
  # output : html div tags for presenting them as a dropdown check box option
  # used in shear app
  #' @export
  dropdown_checkbox_button <-
    function(label = "",
             status = c("default", "primary", "success", "info", "warning", "danger"),
             ...,
             width = NULL) {
      status <- match.arg(status)
      # dropdown button content
      html_ul <- list(
        class = "dropdown-menu",
        style = if (!is.null(width))
          paste0("width: ", validateCssUnit(width), ";"),
        lapply(
          X = list(...),
          FUN = tags$li,
          style = "margin-left: 10px; margin-right: 10px;"
        )
      )
      # dropdown button apparence
      html_button <- list(
        class = paste0("btn btn-", status, " dropdown-toggle"),
        type = "button",
        `data-toggle` = "dropdown"
      )
      html_button <- c(html_button, list(label))
      html_button <- c(html_button, list(tags$span(class = "caret")))
      # final result
      tags$div(
        class = "dropdown",
        do.call(tags$button, html_button),
        do.call(tags$ul, html_ul),
        tags$script(
          "$('.dropdown-menu').click(function(e) {
      e.stopPropagation();
          });"
        )
      )
    }


  # start create summary usinf master table of different method ----
  #' @export
  create_summary_ts <- function(df){
    df %>%
      select(starts_with("ws_pl"),
             starts_with("ws_ll")) %>%
      summarise_all(mean, na.rm = TRUE) %>%
      round(2) -> ts_summary_table
    ts_summary_table %>%
      select(starts_with("ws_ll")) %>%
      t() -> summary_ts
    ts_summary_table %>%
      select(starts_with("ws_pl")) %>%
      t() %>%
      cbind(summary_ts) -> summary_ts
    colnames(summary_ts) <- c("Power","Log")
    summary_ts
  }

  #' @export
  create_summary_const <- function(df){
    df %>%
      select(starts_with("ws_pl"),
             starts_with("ws_ll")) %>%
      summarise_all(mean, na.rm = TRUE) %>%
      round(2)-> const_summary_table
    const_summary_table %>% select(starts_with("ws_ll")) %>%
      t() -> summary_const
    const_summary_table %>%
      select(starts_with("ws_pl")) %>%
      t() %>%
      cbind(summary_const) -> summary_const
    colnames(summary_const) <- c("Power","Log")
    summary_const
  }

  #' @export
  create_summary_month <- function(df){
    df %>%
      select(starts_with("ws_pl"),
             starts_with("ws_ll")) %>%
      round(2) -> bymonth_summary_table
    bymonth_summary_table %>%
      select(-starts_with("month")) %>%
      summarise_all(mean, na.rm = TRUE) %>%
      round(2) -> bymonth_summary_table
    bymonth_summary_table %>%
      select(starts_with("ws_ll")) %>%
      t() -> summary_month
    bymonth_summary_table %>%
      select(starts_with("ws_pl")) %>%
      t() %>%
      cbind(summary_month) -> summary_month
    summary_month
  }

  create_summary_hour <- function(df){
    df %>%
      select(starts_with("ws_pl"),
             starts_with("ws_ll")) %>%
      round(2) -> byhour_summary_table
    byhour_summary_table %>%
      select(-starts_with("hour")) %>%
      summarise_all(mean, na.rm = TRUE) %>%
      round(2) -> byhour_avg
    byhour_avg %>%
      select(starts_with("ws_ll")) %>%
      t() -> summary_byhour
    byhour_avg %>%
      select(starts_with("ws_pl")) %>%
      t() %>%
      cbind(summary_byhour) -> summary_byhour
    summary_byhour
  }

  #' @export
  create_summary_month_hour <- function(df){
    df %>%  select(month,hour,starts_with("ws_pl"),starts_with("ws_ll"))-> by_month_hour_summary_table
    by_month_hour_summary_table %>% select(starts_with("ws_pl"),starts_with("ws_ll")) %>% summarise_all(mean, na.rm = TRUE) -> by_month_hour_avg
    by_month_hour_avg %>% select(starts_with("ws_ll")) %>% t() -> summary_by_month_hour
    by_month_hour_avg %>% select(starts_with("ws_pl")) %>% t() %>% cbind(summary_by_month_hour) -> summary_by_month_hour

  }

  # End create summary usinf master table of different method ----

  #Start create master summary usinf master table of 5 different method ----
  #' @export
  create_master_summary <- function(df1,df2,df3,df4,df5,heights){
    summary_ts <- create_summary_ts(df1)
    summary_const <- create_summary_const(df2)
    summary_month <- create_summary_month(df3)
    summary_hour <- create_summary_hour(df4)
    summary_month_hour <- create_summary_month_hour(df5)

    law <- c("power", "log")
    method <- c("timestamp","constant","month","hour","month_hour")
    height <- heights %>% as.numeric()
    wind_speed <- c(0)

    master_table <- expand.grid(height,law,method,wind_speed)

    ws1 = c(summary_ts[,1],summary_ts[,2])
    ws2 = c(summary_const[,1],summary_const[,2])
    ws3 = c(summary_month[,1],summary_month[,2])
    ws4 = c(summary_hour[,1],summary_hour[,2])
    ws5 = c(summary_month_hour[,1],summary_month_hour[,2])

    master_table[,4] = c(ws1,ws2,ws3,ws4,ws5)
    master_table <-  master_table[c(2,3,1,4)]
    master_table %>%
    mutate_if(is.numeric, round,3) -> master_table
    colnames(master_table) <- c("Law","Method","Height[m]","Windspeed[m/s]")
    return(master_table)
  }
  #End create master summary usinf master table of 5 different method ----

  #Start create gt table using  table and title ----
  #' @export
  create_gt_table <- function(df,name){
    df %>%
      gt( rowname_col = "row",
          groupname_col = "group") %>%
      tab_header(title = name) -> gt_table
  }
  #End create gt table using  table and title ----


#Table column names clean

  #' @export
  column_sensor_rename <- function(sensor_name){
    sensor_name %>%
      toupper() %>%
      str_replace_all("_M_S", " [m/s]") %>%
      str_replace_all("([0-9]+)_([0-9])", ".") %>%
      str_replace_all("_", "") %>%
      str_replace_all("MEAN", "Mean")
  }

  #' @export
  create_ts_freq_dist_plot2 <- function(df,
                                        ib,
                                        max_height_sensor_name_optimal_table){
    df %>%
      dplyr::select(c(ts_alpha_pl_capped,
                      ts_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(ts_alpha_pl_capped,ts_z0_ll_capped),
                   names_to = "names",
                   values_to = "values") %>%
      mutate(names = names %>%
               factor(labels = c(`ts_alpha_pl_capped` = "alpha",
                                 `ts_z0_ll_capped` = "Z[0]"))) %>%
      ggplot() +
      geom_histogram(aes(x = values,
                         fill = max_ht_wind_speed_interval),
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names,
                 scales = "free",
                 labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(#title = ""
            # expression(bold("Frequency Distribution of Shear "~alpha~and~Z[0])),
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 17, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            strip.text = element_text(size = 18, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15),
            legend.position = "top"
      )
  }

  # Start create_value_box_ws----
  #' @export
  create_value_box_ws <- function(df,
                                  input.select_height){
    c_s <- create_summary_const(df)
    c <- expand_grid(c("power", "log"), input.select_height, c(0))
    colnames(c) <- c("Law", "Height[m]", "Windspeed[m/s]")
    c[, 3] <- c(c_s[, 1], c_s[, 2])
    c %>%
      mutate(`Height[m]` =  `Height[m]` %>% factor()) %>%
      datatable(filter = 'top',
                options = list(columnDefs = list(
                  list(className = 'dt-center',
                       targets = 0:3)
                ))) %>%
      formatStyle("Law",
                  fontWeight = 'bold',
                  backgroundColor = styleEqual(c("power", "log"),
                                               c("#FAEBEB", "#F38F8F"))) %>%
      formatStyle("Height[m]",
                  `text-align` = 'center',
                  fontWeight = 'bold') %>%
      formatStyle(
        "Windspeed[m/s]",
        `text-align` = 'left',
        fontWeight = 'bold',
        color = styleInterval(c(3, 6, 9, 12),
                              c('white', 'green', 'red', 'black', 'golden')),
        background = styleColorBar(c(4, 11), 'lightblue', angle = -90),
        backgroundSize = '98% 80%',
        backgroundRepeat = 'no-repeat',
        backgroundPosition = 'center'
      )
  }
  # End create_value_box_ws ----

  # Start create_value_box_alpha_z0 ----
  #' @export
  create_value_box_alpha_z0 <- function(df){
    df %>%
      select(constant_alpha_pl_capped,
             constant_z0_ll_capped) %>%
      mutate_if(is.numeric,round,3) %>%  # -> value_box_constant_plot
      rename("Alpha" = constant_alpha_pl_capped,
             "Z0" = constant_z0_ll_capped) %>%
      datatable(options = list(
        columnDefs = list(list(className = 'dt-center',
                               targets = 0:2)))) %>%
      formatStyle("Alpha",
                  `text-align` = 'center',
                  fontWeight = 'bold',
                  backgroundColor = "#FAEBEB") %>%
      formatStyle("Z0",
                  fontWeight = 'bold',
                  `text-align` = 'center',
                  backgroundColor =  "#F38F8F")
  }
  # End value_box_constant_plot ----

  # Start create_value_box_alpha_z0_bymonth ----
  #' @export
  create_value_box_alpha_z0_bymonth <- function(df){
    df %>%
      select(bymonth_alpha_pl_capped,
             bymonth_z0_ll_capped) %>%
      mutate_if(is.numeric,round,3) %>%  # -> value_box_constant_plot
      rename("Alpha" = bymonth_alpha_pl_capped,
             "Z0" = bymonth_z0_ll_capped) %>%
      datatable(options = list(pageLength = 6,
        columnDefs = list(list(className = 'dt-center',
                               targets = 0:2)))) %>%
      formatStyle("Alpha",
                  `text-align` = 'center',
                  fontWeight = 'bold',
                  backgroundColor = "#FAEBEB") %>%
      formatStyle("Z0",
                  fontWeight = 'bold',
                  `text-align` = 'center',
                  backgroundColor =  "#F38F8F")
  }
  # End create_value_box_alpha_z0_bymonth ----

  # Start create_value_box_alpha_z0_byhour ----
  #' @export
  create_value_box_alpha_z0_byhour <- function(df){
    df %>%
      select(byhour_alpha_pl_capped,
             byhour_z0_ll_capped) %>%
      mutate_if(is.numeric,round,3) %>%
      rename("Alpha" = byhour_alpha_pl_capped,
             "Z0" = byhour_z0_ll_capped) %>%
      datatable(options = list(pageLength = 6,
        columnDefs = list(list(className = 'dt-center',
                               targets = 0:2)))) %>%
      formatStyle("Alpha",
                  `text-align` = 'center',
                  fontWeight = 'bold',
                  backgroundColor = "#FAEBEB") %>%
      formatStyle("Z0",
                  fontWeight = 'bold',
                  `text-align` = 'center',
                  backgroundColor =  "#F38F8F")
  }
  # End create_value_box_alpha_z0_byhour ----

  # Start create_bymonth_freq_dist_plot1 ----
  #' @export
  create_bymonth_freq_dist_plot1 <- function(df,ib,ia,iz0){
    df %>%
      dplyr::select(c(time_window_id,
                      bymonth_alpha_pl_capped,
                      bymonth_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`bymonth_alpha_pl_capped` = "alpha",
                                 `bymonth_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "alpha") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#009e7a"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(
        plot.title = element_text(size=20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(ia),
                 colour = "#009e7a",
                 linetype = 2, size = 1.25)  -> p1
    df %>%
      dplyr::select(c(time_window_id,
                      bymonth_alpha_pl_capped,
                      bymonth_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`bymonth_alpha_pl_capped` = "alpha",
                                 `bymonth_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "Z[0]") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#7471af"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("z0"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(plot.title = element_text(size=20, hjust = 0.5),
            plot.subtitle = element_text(size = 15,
                                         hjust = 0.5),
            axis.title = element_text(size = 15, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            strip.text.x = element_text(size = 17, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(iz0),
                 colour = "#7471af",
                 linetype = 2, size = 1.25) -> p2

    p1 + p2

  }
  # End create_bymonth_freq_dist_plot1 ----
  # Start bymonth_freq_dist_plot2 ----
  #' @export
  create_bymonth_freq_dist_plot2 <- function(df,ib,max_height_sensor_name_optimal_table){
    bymonth_master %>%
      dplyr::select(c(bymonth_alpha_pl_capped, bymonth_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(bymonth_alpha_pl_capped,bymonth_z0_ll_capped),
                   names_to = "names",
                   values_to = "values") %>%
      mutate(names = names %>%
               factor(labels = c(`bymonth_alpha_pl_capped` = "alpha",
                                 `bymonth_z0_ll_capped` = "Z[0]"))) %>%
      ggplot() +
      geom_histogram(aes(x = values,
                         fill = max_ht_wind_speed_interval),
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab(expression(bold("Count"))) +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = expression(bold("Frequency Distribution of Shear "~alpha~and~Z[0])),
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 17, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            strip.text = element_text(size = 18, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)
      )
  }
  # End bymonth_freq_dist_plot2 ----

  # Start create_byhour_freq_dist_plot1 ----
  #' @export
  create_byhour_freq_dist_plot1 <- function(df,ib,ia,iz0){
    df %>%
      dplyr::select(c(time_window_id,byhour_alpha_pl_capped,byhour_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`byhour_alpha_pl_capped` = "alpha", `byhour_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "alpha") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#009e7a"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(
        plot.title = element_text(size = 20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")
      ) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(
        xintercept = c(ia),
        colour = "#009e7a",
        linetype = 2,
        size = 1.25
      )  -> p1


    df %>%
      dplyr::select(c(time_window_id,
                      byhour_alpha_pl_capped,
                      byhour_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`byhour_alpha_pl_capped` = "alpha", `byhour_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "Z[0]") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#7471af"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("z0")) +
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2)) +
      theme(
        plot.title = element_text(size = 20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")
      ) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(
        xintercept = c(iz0),
        colour = "#7471af",
        linetype = 2,
        size = 1.25
      ) -> p2

    p1 + p2

  }
  # End create_byhour_freq_dist_plot1 ----

  # Start byhour_freq_dist_plot2 ----
  #' @export
  create_byhour_freq_dist_plot2 <- function(df,ib,max_height_sensor_name_optimal_table){
    byhour_master %>%
      dplyr::select(c(byhour_alpha_pl_capped,
                      byhour_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(byhour_alpha_pl_capped,byhour_z0_ll_capped),
                   names_to = "names",
                   values_to = "values") %>%
      mutate(names = names %>%
               factor(labels = c(`byhour_alpha_pl_capped` = "alpha",
                                 `byhour_z0_ll_capped` = "Z[0]"))) %>%
      ggplot() +
      geom_histogram(aes(x = values,
                         fill = max_ht_wind_speed_interval),
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = expression(bold("Frequency Distribution of Shear "~alpha~and~Z[0])),
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 17, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            strip.text = element_text(size = 18, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)
      )
  }
  # End byhour_freq_dist_plot2 ----

  # Start by_month_hour_freq_dist_plot1 ----
  #' @export
  create_by_month_hour_freq_dist_plot1 <- function(df,ib,ia,iz0){

    df %>%
      dplyr::select(c(time_window_id,by_month_hour_alpha_pl_capped,
                      by_month_hour_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`by_month_hour_alpha_pl_capped` = "alpha",
                                 `by_month_hour_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "alpha") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#009e7a"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(plot.title = element_text(size=20, hjust = 0.5),
            plot.subtitle = element_text(size = 15,
                                         hjust = 0.5),
            axis.title = element_text(size = 15, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            strip.text.x = element_text(size = 17, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(ia),
                 colour = "#009e7a",
                 linetype = 2, size = 1.25)  -> p1

    df %>%
      dplyr::select(c(time_window_id,by_month_hour_alpha_pl_capped,
                      by_month_hour_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`by_month_hour_alpha_pl_capped` = "alpha",
                                 `by_month_hour_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "Z[0]") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters", values = c("#7471af"), labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("z0"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(
        plot.title = element_text(size = 20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")
      ) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(
        xintercept = c(iz0),
        colour = "#7471af",
        linetype = 2,
        size = 1.25
      ) -> p2

    p1 + p2
  }
  # End by_month_hour_freq_dist_plot1 ----

  # Start by_month_hour_freq_dist_plot2 ----
  #' @export
  create_by_month_hour_freq_dist_plot2 <- function(df,ib,max_height_sensor_name_optimal_table){
    df %>%
      ungroup() %>%
      select("by_month_hour_alpha_pl",
             "by_month_hour_z0_ll",
             all_of(max_height_sensor_name_optimal_table)) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      rename("alpha" = by_month_hour_alpha_pl) %>%
      rename("z[0]" = by_month_hour_z0_ll) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      gather("names",
             "value",
             1:2) %>%
      ggplot() +
      geom_histogram(aes(x = value,
                         fill = max_ht_wind_speed_interval),
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab(expression(bold("Count"))) +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = expression(bold("Frequency Distribution of Shear "~alpha~and~Z[0])),
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 17, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            strip.text = element_text(size = 18, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)
      )
  }
  # End by_month_hour_freq_dist_plot2 ----

  # Start create dt from timestamp----
  #' @export
  create_dt_timestamp <- function(df,input.select_height){
    ts_s <- create_summary_ts(df)
    ts <- expand_grid(c("power","log"),
                      input.select_height,
                      c(0))
    colnames(ts) <- c("Law","Height[m]","Windspeed[m/s]")
    ts[,3] <- c(ts_s[,1],ts_s[,2])
    datatable(ts,
              filter = 'top',
              caption = "TIMESTAMP SUMMARY") %>%
      formatStyle("Law",
                  backgroundColor = styleEqual(c("power","log"),
                                               c("#FAEBEB", "#F38F8F"))) %>%
      formatStyle("Height[m]",
                  `text-align` = 'center') %>%
      formatStyle("Windspeed[m/s]",
                  `text-align` = 'left',
                  color = styleInterval(c(3, 6, 9,12),
                                        c('white', 'yellow', 'red','green','black')),
                  background = styleColorBar( c(4,11),
                                              'lightblue',
                                              angle = -90),
                  backgroundSize = '98% 80%',
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'center')
  }
  # End create dt from timestamp----


  # Start create dt from constant----
  #' @export
  create_dt_constant <- function(df,input.select_height){
    c_s <- create_summary_const(df)
    c <- expand_grid(c("power","log"),
                     input.select_height,
                     c(0))
    colnames(c) <- c("Law","Height[m]","Windspeed[m/s]")
    c[,3] <- c(c_s[,1],c_s[,2])
    datatable(c,
              filter = 'top',
              caption = "CONSTANT SUMMARY") %>%
      formatStyle("Law",backgroundColor = styleEqual(c("power","log"),
                                                     c("#FAEBEB", "#F38F8F"))) %>%
      formatStyle("Height[m]",
                  `text-align` = 'center') %>%
      formatStyle("Windspeed[m/s]",
                  `text-align` = 'left',
                  color = styleInterval(c(3, 6, 9,12),
                                        c('white', 'yellow', 'red','green','black')),
                  background = styleColorBar( c(4,11),
                                              'lightblue',
                                              angle = -90),
                  backgroundSize = '98% 80%',
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'center')
  }
  # End create dt from constant----

  # Start create dt from month----
  #' @export
  create_dt_month <- function(df,input.select_height){
    m_s <- create_summary_month(df)
    m <- expand_grid(c("power","log"),
                     input.select_height,
                     c(0))
    colnames(m) <- c("Law","Height[m]","Windspeed[m/s]")
    m[,3] <- c(m_s[,1],m_s[,2])
    datatable(m,
              filter = 'top',
              caption = "BY MONTH SUMMARY") %>%
      formatStyle("Law",
                  backgroundColor = styleEqual(c("power","log"),
                                               c("#FAEBEB", "#F38F8F"))) %>%
      formatStyle("Height[m]",
                  `text-align` = 'center') %>%
      formatStyle("Windspeed[m/s]",
                  `text-align` = 'left',
                  color = styleInterval(c(3, 6, 9,12),
                                        c('white', 'yellow', 'red','green','black')),
                  background = styleColorBar( c(4,11),
                                              'lightblue',
                                              angle = -90),
                  backgroundSize = '98% 80%',
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'center')
  }
  # End create dt from month----

  # Start create_dt_hour ----
  #' @export
  create_dt_hour <- function(df,input.select_height){
    h_s <- create_summary_hour(df)
    h <- expand_grid(c("power","log"),
                     input.select_height,c(0))
    colnames(h) <- c("Law","Height[m]","Windspeed[m/s]")
    h[,3] <- c(h_s[,1],h_s[,2])
    datatable(h,filter = 'top',
              caption = "HOUR SUMMARY") %>%
      formatStyle("Law",
                  backgroundColor = styleEqual(c("power","log"),
                                               c("#FAEBEB", "#F38F8F"))) %>%
      formatStyle("Height[m]",
                  `text-align` = 'center') %>%
      formatStyle("Windspeed[m/s]",
                  `text-align` = 'left',
                  color = styleInterval(c(3, 6, 9,12),
                                        c('white', 'yellow', 'red','green','black')),
                  background = styleColorBar( c(4,11), 'lightblue', angle = -90),
                  backgroundSize = '98% 80%',
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'center')
  }
  # End create_dt_hour ----

  # Start create_dt_month_hour ----
  #' @export
  create_dt_month_hour <- function(df,input.select_height){
    mh_s <- create_summary_month_hour(df)
    mh <- expand_grid(c("power","log"),
                      input.select_height,c(0))
    colnames(mh) <- c("Law","Height[m]","Windspeed[m/s]")
    mh[,3] <- c(mh_s[,1],mh_s[,2])
    mh[,3] %>% round(3) -> mh[,3]
    datatable(mh,filter = 'top',caption = "MONTH HOUR SUMMARY") %>%
      formatStyle("Law",backgroundColor = styleEqual(c("power","log"),
                                                     c("#FAEBEB", "#F38F8F"))) %>%
      formatStyle("Height[m]",`text-align` = 'center') %>%
      formatStyle("Windspeed[m/s]",
                  `text-align` = 'left',
                  color = styleInterval(c(3, 6, 9,12),
                                        c('white', 'yellow', 'red','green','black')),
                  background = styleColorBar( c(4,11), 'lightblue',angle = -90),
                  backgroundSize = '98% 80%',
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'center')
  }
  # End create_dt_month_hour ----

  # Start create_dt_master ----
  #' @export
  create_dt_master <- function(df){
    colnames(df) <- c("Law","Method","Height[m]","Windspeed[m/s]")
    df["Windspeed[m/s]"] <- round(df["Windspeed[m/s]"],3)
    datatable(df,
              filter = 'top',
              class = 'cell-border stripe',
              options = list(
                pageLength = 20,
                autoWidth = TRUE
              ))  %>%
      formatStyle("Height[m]",
                  `text-align` = 'center') %>%
      formatStyle("Windspeed[m/s]",
                  `text-align` = 'left',
                  color = styleInterval(c(3, 6, 9,12),
                                        c('white', 'green', 'red','black','golden')),
                  background = styleColorBar( c(4,11),
                                              'lightblue',
                                              angle = -90),
                  backgroundSize = '98% 80%',
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'left') %>%
      formatStyle('Law',
                  backgroundColor = styleEqual(c("power","log"), c("#FAEBEB", "#F38F8F"))) %>%
      formatStyle('Method' ,
                  backgroundColor = styleEqual(c("timestamp","constant","month","hour","month_hour"),
                                               c("ivory","lightcyan", "maize","honeydew","pink")))
  }
  # End create_dt_master ----


  # Start create_dt_table_alpha_z0_month_hour ----
  #' @export
  create_dt_table_alpha_z0_month_hour <- function(df){
    df %>% select(
      c(
        month,
        hour,
        by_month_hour_alpha_pl,
        by_month_hour_alpha_pl_capped,
        by_month_hour_z0_ll,
        by_month_hour_z0_ll_capped
      )
    ) %>%
      rename(
        "alpha" = by_month_hour_alpha_pl,
        "alpha_capped" = by_month_hour_alpha_pl_capped,
        "Z0" = by_month_hour_z0_ll,
        "Z0_capped" = by_month_hour_z0_ll_capped,
        "Month" = month,
        "Hour" = hour
      ) %>%
      mutate(Hour = Hour %>% factor()) %>%
      mutate_if(is.numeric, round, 3) %>%
      datatable(
        filter = 'top',
        class = 'cell-border stripe',
        options = list(pageLength = 20,
                       autoWidth = TRUE)
      ) %>%
      formatStyle("alpha",
                  `text-align` = 'left',
                  fontWeight = 'bold',
                  background = styleColorBar( c(0,2), 'lightblue',angle = -90),
                  backgroundSize = '98% 80%',
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'left') %>%
      formatStyle("alpha_capped",
                  `text-align` = 'left',
                  fontWeight = 'bold',
                  background = styleColorBar(c(0,2), 'yellow',angle = -90),
                  backgroundSize = '98% 80%',
                  # backgroundPosition = 'left'
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'left') %>%
      formatStyle("Z0",
                  `text-align` = 'left',
                  fontWeight = 'bold',
                  background = styleColorBar( c(0,6), 'orange',angle = -90),
                  backgroundSize = '98% 80%',
                  # backgroundPosition = 'left'
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'left') %>%
      formatStyle("Z0_capped",
                  `text-align` = 'left',
                  fontWeight = 'bold',
                  background = styleColorBar( c(0,6), 'pink',angle = -90),
                  backgroundSize = '98% 80%',
                  # backgroundPosition = 'left'
                  backgroundRepeat = 'no-repeat',
                  backgroundPosition = 'left') %>%
      formatStyle("Month",
                  fontWeight = 'bold',
                  `text-align` = 'center') %>%
      formatStyle("Hour",
                  fontWeight = 'bold',
                  `text-align` = 'center')
  }
  # End create_dt_table_alpha_z0_month_hour ----

  # Start create_ridge_plot_bymonth ----
  #' @export
  create_ridge_plot_bymonth <- function(df,ib) {
    df %>%
      select(c(date_time,
               ts_alpha_pl_capped,
               ts_z0_ll_capped)) %>%
      mutate(Month = date_time %>%
               lubridate::month(label = TRUE)) %>%
      dplyr::select(-c(date_time)) %>%
      rename("alpha" = "ts_alpha_pl_capped", "z0" = "ts_z0_ll_capped") %>%
      gather("method", "value", 1:2)  %>%
      mutate(Month = Month %>% factor()) %>%
      ggplot(aes(x = value, y = Month)) +
      geom_density_ridges2(
        aes(
          x = value,
          y = Month,
          fill = Month,
          alpha = 0.1
        ),
        show.legend =  FALSE,
        stat = "binline",
        bins = ib,
        scale = 2.2
      ) +
      facet_wrap( ~ method, scales = 'free') +
      ggtitle("Distribution of alpha and z0") +
      theme(
        plot.title = element_text(
          size = 25,
          hjust = 0.5,
          face = "bold"
        ),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")
      )
  }
  # End create_ridge_plot_bymonth ----

  # Start ridge_plot_bymonth_max_ht ----
  #' @export
  create_ridge_plot_bymonth_max_ht <- function(df, ib,max_height_sensor_name_optimal_table) {
    df %>%
      dplyr::select(c(
        date_time,
        ts_alpha_pl_capped,
        ts_z0_ll_capped,
        all_of(max_height_sensor_name_optimal_table)
      )) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      mutate(Month = date_time %>%
               lubridate::month(label = TRUE)) %>%
      dplyr::select(-c(date_time)) %>%
      rename("alpha" = "ts_alpha_pl_capped",
             "z0" = "ts_z0_ll_capped") %>%
      gather("method", "value", 1:2) %>%
      arrange(max_ht_ws)  %>%
      mutate(
        max_ht_wind_speed_interval = max_ht_wind_speed_interval %>% factor(),
        method = method %>% factor(),
        Month = Month %>% factor()
      ) %>%
      ggplot(aes(x = value, y = Month)) +
      geom_density_ridges2(
        aes(
          x = value,
          y = Month,
          fill = max_ht_wind_speed_interval,
          alpha = 0.9
        ),
        stat = "binline",
        bins = ib,
        scale = 2.2
      ) +
      facet_wrap( ~ method, scales = 'free') +
      ggtitle("Distribution of alpha and Z0") +
      theme(
        plot.title = element_text(
          size = 25,
          hjust = 0.5,
          face = "bold"
        ),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")
      )
  }
  # End ridge_plot_bymonth_max_ht ----

  # Start create_ridge_plot_selected_bymonth ----
  #' @export
  create_ridge_plot_selected_bymonth <-
    function(df,ib, input.bymonth_select) {
      df %>%
        select(c(date_time,
                 ts_alpha_pl_capped,
                 ts_z0_ll_capped)) %>%
        mutate(Month = date_time %>%
                 lubridate::month(label = TRUE)) %>%
        dplyr::select(-c(date_time)) %>%
        rename("alpha" = "ts_alpha_pl_capped",
               "z0" = "ts_z0_ll_capped") %>%
        filter(Month %in% input.bymonth_select) %>%
        gather("method", "value", 1:2) %>%
        mutate(Month = Month %>% factor()) %>%
        ggplot() +
        geom_density_ridges2(
          aes(
            x = value,
            y = Month,
            fill = Month,
            alpha = 0.1
          ),
          show.legend = FALSE,
          stat = "binline",
          bins = ib,
          scale = 2.2
        ) +
        facet_wrap( ~ method, scales = 'free') +
        ggtitle("Distribution of alpha and Z0") +
        theme(
          plot.title = element_text(
            size = 25,
            hjust = 0.5,
            face = "bold"
          ),
          axis.title = element_text(size = 15, face = "bold"),
          axis.text = element_text(size = 13, face = "bold"),
          strip.text.x = element_text(size = 17, face = "bold")
        )
    }
  # End create_ridge_plot_selected_bymonth ----

  # Start create_ridge_plot_selected_bymonth_max_ht ----
  #' @export
  create_ridge_plot_selected_bymonth_max_ht <-
    function(df,
             ib,
             input.bymonth_select,
             max_height_sensor_name_optimal_table) {
      df %>%
        dplyr::select(c(
          date_time,
          ts_alpha_pl_capped,
          ts_z0_ll_capped,
          all_of(max_height_sensor_name_optimal_table)
        )) %>%
        rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
        mutate(
          max_ht_wind_speed_interval = case_when(
            max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
            max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
            max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
            max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
            TRUE                      ~ "> 12 m/s"
          )
        ) %>%
        mutate(Month = date_time %>%
                 lubridate::month(label = TRUE)) %>%
        dplyr::select(-c(date_time)) %>%
        filter(Month %in% input.bymonth_select) %>%
        rename("alpha" = "ts_alpha_pl_capped", "z0" = "ts_z0_ll_capped") %>%
        gather("method", "value", 1:2) %>%
        arrange(max_ht_ws)  %>%
        mutate(
          max_ht_wind_speed_interval = max_ht_wind_speed_interval %>% factor(),
          method = method %>% factor(),
          Month = Month %>% factor()
        ) %>%
        ggplot(aes(x = value, y = Month)) +
        geom_density_ridges2(
          aes(
            x = value,
            y = Month,
            fill = max_ht_wind_speed_interval,
            alpha = 0.9
          ),
          stat = "binline",
          bins = ib,
          scale = 2.2
        ) +
        facet_wrap( ~ method, scales = 'free') +
        ggtitle("Distribution of alpha and z0") +
        theme(
          plot.title = element_text(
            size = 25,
            hjust = 0.5,
            face = "bold"
          ),
          axis.title = element_text(size = 15, face = "bold"),
          axis.text = element_text(size = 13, face = "bold"),
          strip.text.x = element_text(size = 17, face = "bold")
        )
    }
  # End create_ridge_plot_selected_bymonth_max_ht ----

  # Start create_ridge_plot_selected_byhour ----
  #' @export
  create_ridge_plot_selected_byhour <-
    function(df, ib, input.byhour_select) {
      df %>%
        select(c(date_time,
                 ts_alpha_pl_capped,
                 ts_z0_ll_capped)) %>%
        mutate(hour = date_time %>% hour()) %>%
        dplyr::select(-c(date_time)) %>%
        rename("alpha" = "ts_alpha_pl_capped",
               "z0" = "ts_z0_ll_capped") %>%
        filter(hour %in% input.byhour_select) %>%
        gather("method", "value", 1:2)  %>%
        mutate(hour = hour %>% factor()) %>%
        ggplot() +
        geom_density_ridges2(
          aes(
            x = value,
            y = hour,
            fill = hour,
            alpha = 0.1
          ),
          show.legend = FALSE,
          stat = "binline",
          bins = ib,
          scale = 2.2
        ) +
        facet_wrap( ~ method,
                    scales = "free") +
        ggtitle("Distribution of alpha and z0") +
        theme(
          plot.title = element_text(
            size = 25,
            hjust = 0.5,
            face = "bold"
          ),
          axis.title = element_text(size = 15, face = "bold"),
          axis.text = element_text(size = 13, face = "bold"),
          strip.text.x = element_text(size = 17, face = "bold")
        )
    }
  # End create_ridge_plot_selected_byhour ----
  # Start ridge_plot_selected_byhour_max_ht ----
  #' @export
  create_ridge_plot_selected_byhour_max_ht <-
    function(df,ib,input.byhour_select,
             max_height_sensor_name_optimal_table) {
      df %>%
        dplyr::select(c(
          date_time,
          ts_alpha_pl_capped,
          ts_z0_ll_capped,
          all_of(max_height_sensor_name_optimal_table)
        )) %>%
        rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
        mutate(
          max_ht_wind_speed_interval = case_when(
            max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
            max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
            max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
            max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
            TRUE                      ~ "> 12 m/s"
          )
        ) %>%
        mutate(hour = date_time %>% hour()) %>%
        dplyr::select(-c(date_time)) %>%
        rename("alpha" = "ts_alpha_pl_capped", "z0" = "ts_z0_ll_capped") %>%
        filter(hour %in% input.byhour_select) %>%
        gather("method", "value", 1:2) %>%
        arrange(max_ht_ws) %>%
        mutate(
          max_ht_wind_speed_interval = max_ht_wind_speed_interval %>% factor(),
          method = method %>% factor(),
          hour = hour %>% factor()
        ) %>%
        ggplot(aes(x = value, y = hour)) +
        geom_density_ridges2(
          aes(
            x = value,
            y = hour,
            fill = max_ht_wind_speed_interval,
            alpha = 0.9
          ),
          stat = "binline",
          bins = ib,
          scale = 2.2
        ) +
        facet_wrap( ~ method, scales = "free") +
        ggtitle("Distribution of alpha and Z0") +
        theme(
          plot.title = element_text(
            size = 25,
            hjust = 0.5,
            face = "bold"
          ),
          axis.title = element_text(size = 15, face = "bold"),
          axis.text = element_text(size = 13, face = "bold"),
          strip.text.x = element_text(size = 17, face = "bold")
        )
    }
  # End ridge_plot_selected_byhour_max_ht ----



  # Start ts_freq_dist_plot1 ----
  #' @export
  create_ts_freq_dist_plot1 <- function(df,ib,ia,iz0){
    df %>%
      dplyr::select(c(time_window_id,
                      ts_alpha_pl_capped,
                      ts_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`ts_alpha_pl_capped` = "alpha",
                                 `ts_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "alpha") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#009e7a"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(legend.position = "top",
        plot.title = element_text(size=20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(ia),
                 colour = "#009e7a",
                 linetype = 2, size = 1.25)  -> p1


    df %>%
      dplyr::select(c(time_window_id,
                      ts_alpha_pl_capped,
                      ts_z0_ll_capped)) %>%
      pivot_longer(-time_window_id,
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`ts_alpha_pl_capped` = "alpha",
                                 `ts_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "Z[0]") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib,
                    size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#7471af"),
                         labels = c(expression(alpha),
                                    expression(Z[0]))) +
      labs(title = paste0("z0"))+
      #facet_wrap(~names, scales = "free", labeller = label_parsed)+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(#plot.title = ggtext::element_markdown(hjust = 0.5),
        plot.title = element_text(size=20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 15, face = "bold"),
        axis.text = element_text(size = 13, face = "bold"),
        strip.text.x = element_text(size = 17, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(iz0),
                 colour = "#7471af",
                 linetype = 2,
                 size = 1.25) -> p2

    p1 + p2

  }
  # End ts_freq_dist_plot1 ----

  # Start create_optimal_heights ----
  #' @export
  create_optimal_heights <- function(input.select_height,input.windsensor,input.hts_for_computation){
    tibble(input_heights = input.select_height,
           nearest_sensor_heights = input.select_height %>%
             map_dbl(get_nearest_height_val,
                     input.windsensor %>%
                       parse_number()),
           nearest_override_sensor_heights = input.select_height %>%
             map_dbl(get_nearest_height_val,
                     input.hts_for_computation)) %>%
      mutate(nearest_override_sensor_heights_colname =
               paste0("ws_",
                      nearest_override_sensor_heights,
                      "_mean_m_s"))
  }
  # End create_optimal_heights ----



  #' @export
  f <- function(k) {
    step <- k
    function(x) seq(floor(min(x)), ceiling(max(x)), by = step)
  }


  # Start create_constant_plot ----
  #' @export
  create_constant_plot <- function(ws_constant,
                                   constant_predicted_transposed,
                                   constant_predicted_transposed_ml,
                                   heights){
    ggplot() +
      geom_point(data = ws_constant,
                 aes(x = ws,
                     y = ht),
                 size = 5,
                 shape = "+",
                 show.legend = FALSE) +
      geom_point(data = constant_predicted_transposed,
                 aes(x = ws,
                     y = height,
                     color = law),
                 size = 10,
                 shape = "+") +
      geom_line(data = constant_predicted_transposed_ml,
                aes(x = ws,
                    y = height,
                    color = law),
                linetype = 2,
                alpha = 0.6) +
      scale_color_brewer("",
                         palette = "Dark2") +
      labs(x = "Mean Wind Speed (m/s)",
           y = "Height Above Ground (m)",
           color = "Law") +
      theme_bw(base_size = 8) +
      scale_y_continuous(breaks = seq(0,max(heights),
                                      by = 10),
                         limits = c(0,max(heights))) +
      scale_x_continuous(breaks = seq(0:25),
                         limits = c(0,15)) +
      theme(panel.grid.major = element_line("gray",
                                            linetype = 1),
            panel.grid.minor = element_line("gray"),
            plot.title = ggtext::element_markdown(hjust = 0.5),
            plot.subtitle = element_text(size = 15,
                                         hjust = 0.5),
            axis.title = element_text(size = 17, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            legend.text = element_text(face = "bold", size = 16),
            legend.title = element_text(face = "bold", size = 18),
            legend.position = "top")
  }

  # End create_constant_plot ----

  # Start create_bymonth_plot ----
  #' @export
  create_bymonth_plot <- function(ws_bymonth_filtered,
                                  bymonth_predicted_transposed_filtered,
                                  bymonth_predicted_transposed_filtered_ml,
                                  heights){
    ggplot() +
      geom_point(data = ws_bymonth_filtered,
                 aes(x = ws,
                     y = ht,
                     color = month),
                 shape = "+",
                 size = 5) +
      geom_point(data = bymonth_predicted_transposed_filtered,
                 aes(x = ws,
                     y = height,
                     shape = law,
                     color = month),
                 size = 7,
                 stroke = 2,
                 show.legend = T) +
      geom_line(data = bymonth_predicted_transposed_filtered_ml,
                aes(x = ws,
                    y = height,
                    color = month),
                linetype = 2,
                alpha = 0.2,
                show.legend = T) +
      scale_colour_brewer("",
                          palette="Dark2") +
      labs(x = "Mean Wind Speed (m/s)",
           y = "Height Above Ground (m)",
           shape = "Law",
           color = "Month") +
      theme_bw(base_size = 8) +
      scale_y_continuous(breaks = seq(0,max(heights), by = 10),
                         limits = c(0,max(heights))) +
      scale_x_continuous(breaks = seq(0:25),
                         limits = c(0,15)) +
      theme(panel.grid.major = element_line("gray",
                                            linetype = 1),
            panel.grid.minor=element_line("gray"),
            plot.title = ggtext::element_markdown(hjust = 0.5),
            plot.subtitle = element_text(size = 15,
                                         hjust = 0.5),
            axis.title = element_text(size = 17, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            legend.text = element_text(face = "bold", size = 16),
            legend.title = element_text(face = "bold", size = 18),
            legend.position = "top"
      )
  }

  # End create_bymonth_plot ----

  # Start create_byhour_plot ----
  #' @export
  create_byhour_plot <- function(ws_byhour_filtered,
                                 byhour_predicted_transposed_filtered,
                                 byhour_predicted_transposed_ml_filtered,
                                 heights){
    ggplot() +
      geom_point(data = ws_byhour_filtered,
                 aes(x = ws,
                     y = ht,
                     color = hour),
                 size = 5,
                 shape = "+") +
      geom_point(data = byhour_predicted_transposed_filtered,
                 aes(x = ws,
                     y = height,
                     color = hour,
                     shape = law),
                 size = 7,
                 show.legend = TRUE) +
      geom_line(data = byhour_predicted_transposed_ml_filtered,
                aes(x = ws,
                    y = height,
                    color = hour),
                linetype = 2,
                alpha = 0.2,
                show.legend = TRUE) +
      scale_color_brewer("",palette = "Dark2") +
      labs(x = "Mean Wind Speed (m/s)",
           y = "Height Above Ground (m)",
           shape = "Law",
           color = "Month") +
      theme_bw(base_size = 8) +
      scale_y_continuous(breaks = seq(0,max(heights), by = 10),
                         limits = c(0,max(heights))) +
      scale_x_continuous(breaks = seq(0:25),
                         limits = c(0,15)) +
      theme(panel.grid.major = element_line("gray",
                                            linetype = 1),
            panel.grid.minor=element_line("gray"),
            plot.title = ggtext::element_markdown(hjust = 0.5),
            plot.subtitle = element_text(size = 15,
                                         hjust = 0.5),
            axis.title = element_text(size = 17, face = "bold"),
            axis.text = element_text(size = 13, face = "bold"),
            legend.text = element_text(face = "bold", size = 16),
            legend.title = element_text(face = "bold", size = 18),
            legend.position = "top"
      )
  }
  # Start create_byhour_plot ----


  # Start create_diurnal_master ----
  #' @export
  create_diurnal_master <- function(byhour_master,
                                    max_height_sensor_name_optimal_table){
    byhour_master %>%
      dplyr::select(c(
        hour,
        byhour_alpha_pl_capped,
        byhour_z0_ll_capped,
        all_of(max_height_sensor_name_optimal_table)
      )) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      rename("alpha_capped" = byhour_alpha_pl_capped) %>%
      rename("z0_capped" = byhour_z0_ll_capped) %>%
      pivot_longer(c("alpha_capped", "z0_capped"),
                   names_to = "law",
                   values_to = "values") %>%
      mutate(max_ht_wind_speed_interval = max_ht_wind_speed_interval %>% factor(),
             law = law %>% factor())
  }
  # End create_diurnal_master ----

  # Start create_diurnal_plot ----
  #' @export
  create_diurnal_plot <- function(diurnal_master){
    diurnal_master %>%
      ggplot(aes(x = hour,
                 y = values,
                 fill = max_ht_wind_speed_interval)) +
      ggtitle("Variation of alpha & z0 by hour") +
      theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 18),
            strip.text.x = element_text(size = 12, face = "bold.italic"),
            axis.title= element_text(face = "bold")) +
      geom_col(show.legend = FALSE) +
      facet_wrap(~law, scales = "free_y", ncol = 1)
  }
  # End create_diurnal_plot ----

  # Start create_ts_overlay_freq_dist_plot ----
  #' @export
  create_ts_overlay_freq_dist_plot <- function(df,ib,ia,iz0,max_height_sensor_name_optimal_table){
    df %>%
      dplyr::select(c(ts_alpha_pl_capped, ts_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(ts_alpha_pl_capped,
                     ts_z0_ll_capped),
                   names_to = "names",
                   values_to = "values") %>%
      mutate(names = names %>%
               factor(labels = c(`ts_alpha_pl_capped` = "alpha",
                                 `ts_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "alpha") %>%
      ggplot() +
      geom_freqpoly(aes(x = values,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("darkgreen"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(plot.title = element_text(size=20, hjust = 0.5),
            plot.subtitle = element_text(size = 15,
                                         hjust = 0.5),
            axis.title = element_text(size = 18,
                                      face = "bold"),
            axis.text = element_text(size = 18,
                                     face = "bold"),
            strip.text.x = element_text(size = 28,
                                        face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(ia),
                 colour = "darkgreen",
                 linetype = 2, size = 1.25) +
      geom_histogram(aes(x = values,
                         fill = max_ht_wind_speed_interval),
                     alpha = 0.5,
                     show.legend = F,
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = "",
           #labs(title = expression(bold("Frequency Distribution of Shear "~alpha)),
           fill = "Wind Speed for Max \nSelected Height")+
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)) -> overlay1
    df %>%
      dplyr::select(c(ts_alpha_pl_capped, ts_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      #rename("max_ht_ws" = all_of(max_ht_mean_colname)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(ts_alpha_pl_capped,ts_z0_ll_capped),
                   names_to = "names",
                   values_to = "values") %>%
      mutate(names = names %>% factor(labels = c(`ts_alpha_pl_capped` = "alpha", `ts_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "Z[0]") %>%
      ggplot() +
      geom_freqpoly(aes(x = values,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters", values = c("#7471af"), labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Z[0]"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(plot.title = element_text(size=30, hjust = 0.5, face = "bold"),
            plot.subtitle = element_text(size = 15,
                                         hjust = 0.5),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text.x = element_text(size = 28, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(iz0),
                 colour = "#7471af",
                 linetype = 2, size = 1.25) +

      geom_histogram(aes(x = values,
                         fill = max_ht_wind_speed_interval),
                     alpha = 0.5,
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = "",
           #labs(title = expression(bold("Frequency Distribution of Shear "~Z[0])),
           fill = "Wind Speed for Max \nSelected Height")  +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)) -> overlay2
    overlay1 + overlay2
  }

  # End create_ts_overlay_freq_dist_plot ----

  # Start create_bymonth_overlay_freq_dist_plot ----

  #' @export
  create_bymonth_overlay_freq_dist_plot <- function(df,ib,ia,iz0,max_height_sensor_name_optimal_table){
    df %>%
      dplyr::select(c(bymonth_alpha_pl_capped,
                      bymonth_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(bymonth_alpha_pl_capped,
                     bymonth_z0_ll_capped),
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>% factor(labels = c(`bymonth_alpha_pl_capped` = "alpha",
                                                 `bymonth_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "alpha") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("darkgreen"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(plot.title = element_text(size=20, hjust = 0.5),
            plot.subtitle = element_text(size = 15,hjust = 0.5),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text.x = element_text(size = 28, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(ia),
                 colour = "darkgreen",
                 linetype = 2, size = 1.25) +
      geom_histogram(aes(x = value,
                         alpha = 0.5,
                         fill = max_ht_wind_speed_interval),
                     bins = ib,
                     show.legend = F) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab(expression(bold("Count"))) +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = "",
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)) -> bymonth_overlay1

    df %>%
      dplyr::select(c(bymonth_alpha_pl_capped, bymonth_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(bymonth_alpha_pl_capped,bymonth_z0_ll_capped),
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`bymonth_alpha_pl_capped` = "alpha",
                                 `bymonth_z0_ll_capped` = "Z[0]"))) %>%
      filter(names == "Z[0]") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#7471af"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Z[0]"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(plot.title = element_text(size=20, hjust = 0.5),
            plot.subtitle = element_text(size = 15, hjust = 0.5),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text.x = element_text(size = 28, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(iz0),
                 colour = "#7471af",
                 linetype = 2, size = 1.25) +
      geom_histogram(aes(x = value,
                         alpha = 0.5,
                         fill = max_ht_wind_speed_interval),
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab(expression(bold("Count"))) +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = "",
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)) -> bymonth_overlay2

    bymonth_overlay1 + bymonth_overlay2
  }

  # End create_bymonth_overlay_freq_dist_plot ----

  # Start create_byhour_overlay_freq_dist_plot ----

  #' @export
  create_byhour_overlay_freq_dist_plot <- function(df,ib,ia,iz0,max_height_sensor_name_optimal_table){
    df %>%
      dplyr::select(c(byhour_alpha_pl_capped, byhour_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(byhour_alpha_pl_capped,byhour_z0_ll_capped),
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`byhour_alpha_pl_capped` = "alpha",
                                 `byhour_z0_ll_capped` = "Z[0]"))) %>%

      filter(names == "alpha") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("darkgreen"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(plot.title = element_text(size=20, hjust = 0.5),
            plot.subtitle = element_text(size = 15, hjust = 0.5),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text.x = element_text(size = 28, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(ia),
                 colour = "darkgreen",
                 linetype = 2, size = 1.25) +
      geom_histogram(aes(x = value,
                         alpha =0.5,
                         fill = max_ht_wind_speed_interval),
                     bins = ib,
                     show.legend = F) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = " ",
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15) ) -> byhour_overlay1




    df %>%
      dplyr::select(c(byhour_alpha_pl_capped, byhour_z0_ll_capped,
                      all_of(max_height_sensor_name_optimal_table))) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )
      ) %>%
      pivot_longer(c(byhour_alpha_pl_capped,byhour_z0_ll_capped),
                   names_to = "names",
                   values_to = "value") %>%
      mutate(names = names %>%
               factor(labels = c(`byhour_alpha_pl_capped` = "alpha",
                                 `byhour_z0_ll_capped` = "Z[0]"))) %>%

      filter(names == "Z[0]") %>%
      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters", values = c("#7471af"), labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Z[0]"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(#plot.title = ggtext::element_markdown(hjust = 0.5),
        plot.title = element_text(size=20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 18, face = "bold"),
        axis.text = element_text(size = 18, face = "bold"),
        strip.text.x = element_text(size = 28, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(iz0),
                 colour = "#7471af",
                 linetype = 2, size = 1.25) +
      geom_histogram(aes(x = value,
                         alpha =0.5,
                         fill = max_ht_wind_speed_interval),
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free", labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = "",
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15) ) -> byhour_overlay2
    byhour_overlay1 + byhour_overlay2

  }

  # End create_byhour_overlay_freq_dist_plot ----



  # Start create_by_month_hour_overlay_freq_dist_plot ----

  #' @export
  create_by_month_hour_overlay_freq_dist_plot <- function(df,ib,ia,iz0,max_height_sensor_name_optimal_tables){
    df %>%
      ungroup() %>%
      select("by_month_hour_alpha_pl","by_month_hour_z0_ll",
             all_of(max_height_sensor_name_optimal_table)) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      rename("alpha" = by_month_hour_alpha_pl) %>%
      rename("z[0]" = by_month_hour_z0_ll) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )

      ) %>%
      gather("names","value",1:2) %>%
      filter(names == "alpha") %>%

      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("darkgreen"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Alpha"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(#plot.title = ggtext::element_markdown(hjust = 0.5),
        plot.title = element_text(size=20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 18, face = "bold"),
        axis.text = element_text(size = 18, face = "bold"),
        strip.text.x = element_text(size = 28, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(ia),
                 colour = "darkgreen",
                 linetype = 2, size = 1.25) +
      geom_histogram(aes(x = value,
                         fill = max_ht_wind_speed_interval),
                     alpha = 0.5,
                     show.legend = F,
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free",
                 labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab(expression(bold("Count"))) +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = "",
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)) -> by_month_hour_overlay1



    df %>%
      ungroup() %>%
      select("by_month_hour_alpha_pl","by_month_hour_z0_ll",
             all_of(max_height_sensor_name_optimal_table)) %>%
      rename("max_ht_ws" = all_of(max_height_sensor_name_optimal_table)) %>%
      rename("alpha" = by_month_hour_alpha_pl) %>%
      rename("z[0]" = by_month_hour_z0_ll) %>%
      mutate(
        max_ht_wind_speed_interval = case_when(
          max_ht_ws > 0 & max_ht_ws < 3 ~ "0 - 3 m/s",
          max_ht_ws >= 3 & max_ht_ws < 6 ~ "3 - 6 m/s",
          max_ht_ws >= 6 & max_ht_ws < 9 ~ "6 - 9 m/s",
          max_ht_ws >= 9 & max_ht_ws < 12 ~ "9 - 12 m/s",
          TRUE                      ~ "> 12 m/s"
        )

      ) %>%
      gather("names","value",1:2) %>%
      filter(names == "z[0]") %>%

      ggplot() +
      geom_freqpoly(aes(x = value,
                        color = names),
                    bins = ib, size = 1.5,
                    show.legend = F) +
      scale_color_manual(name = "Parameters",
                         values = c("#7471af"),
                         labels = c(expression(alpha), expression(Z[0]))) +
      labs(title = paste0("Z[0]"))+
      xlab("Value") +
      ylab("Count") +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line(linetype = 2))+
      theme(#plot.title = ggtext::element_markdown(hjust = 0.5),
        plot.title = element_text(size=20, hjust = 0.5),
        plot.subtitle = element_text(size = 15,
                                     hjust = 0.5),
        axis.title = element_text(size = 18, face = "bold"),
        axis.text = element_text(size = 18, face = "bold"),
        strip.text.x = element_text(size = 28, face = "bold")) +
      scale_x_continuous(limits = NULL) +
      scale_y_continuous(limits = NULL) +
      geom_vline(xintercept = c(iz0),
                 colour = "#7471af",
                 linetype = 2, size = 1.25) +
      geom_histogram(aes(x = value,
                         fill = max_ht_wind_speed_interval),
                     alpha = 0.5,
                     bins = ib) +
      scale_fill_brewer(palette = "Dark2") +
      facet_wrap(~names, scales = "free",
                 labeller = label_parsed) +
      xlab(expression(bold("Value"))) +
      ylab(expression(bold("Count"))) +
      theme_bw(base_size = 8) +
      theme(panel.grid = element_line("gray",
                                      linetype = 1)) +
      labs(title = "",
           fill = "Wind Speed for Max \nSelected Height") +
      theme(plot.title = element_text(size = 25,
                                      hjust=0.5, face = "bold"),
            axis.title = element_text(size = 18, face = "bold"),
            axis.text = element_text(size = 18, face = "bold"),
            strip.text = element_text(size = 28, face = "bold"),
            legend.text = element_text(face = "bold", size = 14),
            legend.title = element_text(face = "bold", size = 15)) -> by_month_hour_overlay2
    by_month_hour_overlay1 + by_month_hour_overlay2

  }

  # End create_by_month_hour_overlay_freq_dist_plot ----







